;============================================================================
; ASX BIOS - Low-Level Hardware Control
; Architecture for Synthesized eXchange
; Version 1.0 - (C) 1986 ASX Systems, Inc.
;
; This module handles:
;   - System initialization and reset
;   - Interrupt handling (VBlank, Keyboard, Timer)
;   - Low-level I/O port operations
;   - Stack management
;   - Memory test and verification
;   - Boot sequence and cartridge detection
;
; Memory Layout:
;   ROM: 0x8000 - 0xBFFF (16 KB)
;   RAM: 0x0000 - 0x1FFF (8 KB)
;============================================================================

    .module bios
    .area   _BIOS (ABS)

;----------------------------------------------------------------------------
; BIOS Entry Points (fixed addresses for compatibility)
;----------------------------------------------------------------------------
    .org    0x8000

; BIOS Jump Table - All BIOS calls go through here
; Applications should use these fixed addresses for forward compatibility
BIOS_JUMP_TABLE:
    jp      bios_init           ; 0x8000 - Initialize system
    jp      bios_interrupt      ; 0x8003 - Trigger software interrupt
    jp      bios_in             ; 0x8006 - Read from I/O port
    jp      bios_out            ; 0x8009 - Write to I/O port
    jp      bios_halt           ; 0x800C - Halt CPU
    jp      bios_mem_test       ; 0x800F - Test RAM
    jp      bios_reset          ; 0x8012 - Soft reset
    jp      bios_version        ; 0x8015 - Get BIOS version
    jp      bios_delay          ; 0x8018 - Delay routine
    jp      bios_beep           ; 0x801B - Speaker beep
    jp      bios_checksum       ; 0x801E - Calculate checksum
    jp      bios_copy           ; 0x8021 - Fast memory copy
    jp      bios_fill           ; 0x8024 - Fast memory fill

;----------------------------------------------------------------------------
; BIOS Version String
;----------------------------------------------------------------------------
BIOS_VERSION:
    .ascii  "ASX BIOS v1.0.3"
    .db     0x00

BIOS_COPYRIGHT:
    .ascii  "(C) 1986 ASX Systems, Inc."
    .db     0x0D, 0x0A
    .ascii  "All Rights Reserved."
    .db     0x00

;----------------------------------------------------------------------------
; System Constants
;----------------------------------------------------------------------------
RAM_SIZE        =   0x2000      ; 8 KB
RAM_BASE        =   0x0000
RAM_TOP         =   0x1FFF
STACK_TOP       =   0x1FFF

ROM_BIOS_BASE   =   0x8000
ROM_BASIC_BASE  =   0xC000

PORT_VRAM_ADDR  =   0x98
PORT_VRAM_DATA  =   0x98
PORT_VDP_CMD    =   0x99
PORT_PSG        =   0xA0
PORT_JOY1       =   0xA8
PORT_JOY2       =   0xA9
PORT_KBD        =   0xAA
PORT_CART       =   0xAB

; System Variable Offsets
SV_FLAGS        =   0x0000
SV_SCREEN       =   0x0001
SV_CURSOR_X     =   0x0002
SV_CURSOR_Y     =   0x0003
SV_TICK_LO      =   0x0007
SV_TICK_HI      =   0x0008
SV_INT_COUNT    =   0x002A

;----------------------------------------------------------------------------
; Interrupt Vectors (placed at known locations)
;----------------------------------------------------------------------------
    .org    0x8100

INT_VBLANK:
    push    af
    push    bc
    push    de
    push    hl
    push    ix
    push    iy

    ; Increment tick counter (16-bit, Little-Endian)
    ld      hl, #SV_TICK_LO
    inc     (hl)                ; Increment low byte
    jr      nz, .tick_no_carry
    inc     hl
    inc     (hl)                ; Increment high byte
.tick_no_carry:

    ; Increment interrupt counter
    ld      hl, #SV_INT_COUNT
    inc     (hl)

    ; Read VDP status to clear interrupt flag
    in      a, (#PORT_VDP_CMD)
    ld      (#SV_FLAGS + 0x29), a   ; Cache VDP status

    ; Call VBlank handler if registered
    ld      hl, (vblank_handler)
    ld      a, h
    or      l
    jr      z, .no_vblank_handler
    call    .call_vblank
.no_vblank_handler:

    pop     iy
    pop     ix
    pop     hl
    pop     de
    pop     bc
    pop     af
    ei
    reti

.call_vblank:
    jp      (hl)

vblank_handler:
    .dw     0x0000

;----------------------------------------------------------------------------
; Keyboard Interrupt Handler
;----------------------------------------------------------------------------
INT_KEYBOARD:
    push    af
    push    bc
    push    de
    push    hl

    ; Scan keyboard matrix
    call    kbd_scan

    pop     hl
    pop     de
    pop     bc
    pop     af
    ei
    reti

;----------------------------------------------------------------------------
; Timer Interrupt Handler
;----------------------------------------------------------------------------
INT_TIMER:
    push    af
    push    hl

    ; Timer tick - 60Hz on NTSC, 50Hz on PAL
    ld      hl, #timer_ticks
    inc     (hl)

    pop     hl
    pop     af
    ei
    reti

timer_ticks:
    .db     0x00

;----------------------------------------------------------------------------
; BIOS_INIT - Initialize the ASX System
; Input:  None
; Output: None
; Clobbers: AF, BC, DE, HL
;----------------------------------------------------------------------------
    .org    0x8200

bios_init:
    ; Disable interrupts during initialization
    di

    ; Set up stack pointer
    ld      sp, #STACK_TOP

    ; Clear system variables (0x0000 - 0x00FF)
    ld      hl, #RAM_BASE
    ld      de, #RAM_BASE + 1
    ld      bc, #0x00FF
    ld      (hl), #0x00
    ldir

    ; Initialize tick counter to 0
    xor     a
    ld      (#SV_TICK_LO), a
    ld      (#SV_TICK_HI), a

    ; Set default screen mode to 0 (Standard Text)
    ld      a, #0x00
    ld      (#SV_SCREEN), a

    ; Set default colors (white on black)
    ld      a, #0x0F
    ld      (#0x0005), a        ; Foreground
    ld      a, #0x01
    ld      (#0x0006), a        ; Background

    ; Initialize cursor position
    ld      a, #0x00
    ld      (#SV_CURSOR_X), a
    ld      (#SV_CURSOR_Y), a

    ; Initialize keyboard buffer
    ld      a, #0x00
    ld      (#0x0009), a        ; Head
    ld      (#0x000A), a        ; Tail

    ; Initialize VDP
    call    vdp_init_hw

    ; Initialize PSG (sound)
    call    psg_init_hw

    ; Test RAM
    call    bios_mem_test
    jr      c, .ram_ok

    ; RAM test failed - show error
    ld      hl, #ram_error_msg
    call    bios_print_error
    jr      .halt_system

.ram_ok:
    ; Check for cartridge
    call    cart_detect
    jr      c, .cart_found

    ; No cartridge - boot into BASIC
    ld      a, #SYS_BASIC_ACTIVE
    ld      (#SV_FLAGS), a

    ; Print boot message
    ld      hl, #boot_msg
    call    bios_print_string

    ; Enable interrupts and jump to BASIC
    ei
    jp      ROM_BASIC_BASE

.cart_found:
    ; Cartridge detected - set flag and execute
    ld      a, (#SV_FLAGS)
    or      #SYS_CART_INSERTED
    ld      (#SV_FLAGS), a

    ld      hl, #cart_boot_msg
    call    bios_print_string

    ; Enable interrupts and execute cartridge
    ei
    call    cart_execute

    ; If cartridge returns, fall through to BASIC
    ld      hl, #cart_return_msg
    call    bios_print_string
    jp      ROM_BASIC_BASE

.halt_system:
    halt
    jr      .halt_system

;----------------------------------------------------------------------------
; BIOS_INTERRUPT - Software Interrupt
; Input:  A = Interrupt vector number
; Output: None
;----------------------------------------------------------------------------
bios_interrupt:
    push    hl
    push    bc

    ; Vector table at 0x8300
    ld      hl, #int_vector_table
    ld      b, #0x00
    ld      c, a
    add     hl, bc
    add     hl, bc              ; HL = table + vector * 2

    ; Load handler address
    ld      c, (hl)
    inc     hl
    ld      b, (hl)
    ld      hl, bc

    pop     bc
    ex      (sp), hl            ; Replace return address with handler
    ret                         ; Jump to handler

;----------------------------------------------------------------------------
; BIOS_IN - Read from I/O Port
; Input:  C = Port number
; Output: A = Data read
;----------------------------------------------------------------------------
bios_in:
    in      a, (c)
    ret

;----------------------------------------------------------------------------
; BIOS_OUT - Write to I/O Port
; Input:  C = Port number, A = Data to write
; Output: None
;----------------------------------------------------------------------------
bios_out:
    out     (c), a
    ret

;----------------------------------------------------------------------------
; BIOS_HALT - Halt CPU until next interrupt
; Input:  None
; Output: None
;----------------------------------------------------------------------------
bios_halt:
    halt
    ret

;----------------------------------------------------------------------------
; BIOS_MEM_TEST - Test RAM integrity
; Input:  None
; Output: Carry set if OK, clear if failed
; Clobbers: AF, BC, DE, HL
;----------------------------------------------------------------------------
bios_mem_test:
    push    hl
    push    de
    push    bc

    ; Test pattern 1: 0x55
    ld      hl, #RAM_BASE
    ld      bc, #RAM_SIZE
.test_loop_1:
    ld      (hl), #0x55
    ld      a, (hl)
    cp      #0x55
    jr      nz, .test_fail
    inc     hl
    dec     bc
    ld      a, b
    or      c
    jr      nz, .test_loop_1

    ; Test pattern 2: 0xAA
    ld      hl, #RAM_BASE
    ld      bc, #RAM_SIZE
.test_loop_2:
    ld      (hl), #0xAA
    ld      a, (hl)
    cp      #0xAA
    jr      nz, .test_fail
    inc     hl
    dec     bc
    ld      a, b
    or      c
    jr      nz, .test_loop_2

    ; Test pattern 3: Walking bit
    ld      hl, #RAM_BASE
    ld      b, #8
.walk_loop:
    scf
    rl      a
    ld      (hl), a
    cp      (hl)
    jr      nz, .test_fail
    djnz    .walk_loop

    ; All tests passed
    scf                         ; Set carry = success
    jr      .test_done

.test_fail:
    or      a                   ; Clear carry = failure

.test_done:
    pop     bc
    pop     de
    pop     hl
    ret

;----------------------------------------------------------------------------
; BIOS_RESET - Soft Reset
; Input:  None
; Output: None
;----------------------------------------------------------------------------
bios_reset:
    di
    ld      sp, #STACK_TOP
    jp      bios_init

;----------------------------------------------------------------------------
; BIOS_VERSION - Get BIOS Version
; Input:  None
; Output: HL = Pointer to version string
;----------------------------------------------------------------------------
bios_version:
    ld      hl, #BIOS_VERSION
    ret

;----------------------------------------------------------------------------
; BIOS_DELAY - Delay routine
; Input:  BC = Number of iterations
; Output: None
;----------------------------------------------------------------------------
bios_delay:
    push    bc
.delay_loop:
    dec     bc
    ld      a, b
    or      c
    jr      nz, .delay_loop
    pop     bc
    ret

;----------------------------------------------------------------------------
; BIOS_BEEP - Speaker beep
; Input:  None
; Output: None
;----------------------------------------------------------------------------
bios_beep:
    push    af
    push    bc
    push    de

    ; Set PSG channel A tone to ~1kHz
    ld      a, #0x80            ; Tone A coarse = 0
    out     (#PORT_PSG), a
    ld      a, #0x00
    out     (#PORT_PSG), a
    ld      a, #0x90            ; Tone A fine = 56 (~1kHz at 3.58MHz)
    out     (#PORT_PSG), a
    ld      a, #56
    out     (#PORT_PSG), a

    ; Enable tone on channel A
    ld      a, #0x07            ; Mixer register
    out     (#PORT_PSG), a
    ld      a, #0x3E            ; Enable tone A, disable noise
    out     (#PORT_PSG), a

    ; Set volume
    ld      a, #0x90            ; Channel A volume
    out     (#PORT_PSG), a
    ld      a, #0x0F            ; Max volume
    out     (#PORT_PSG), a

    ; Delay
    ld      bc, #0x2000
    call    bios_delay

    ; Mute
    ld      a, #0x90
    out     (#PORT_PSG), a
    ld      a, #0x00
    out     (#PORT_PSG), a

    pop     de
    pop     bc
    pop     af
    ret

;----------------------------------------------------------------------------
; BIOS_CHECKSUM - Calculate checksum of memory block
; Input:  HL = Start address, BC = Length
; Output: A = Checksum (sum of all bytes)
;----------------------------------------------------------------------------
bios_checksum:
    push    hl
    push    bc
    xor     a
.chk_loop:
    add     a, (hl)
    inc     hl
    dec     bc
    ld      d, a
    ld      a, b
    or      c
    ld      a, d
    jr      nz, .chk_loop
    pop     bc
    pop     hl
    ret

;----------------------------------------------------------------------------
; BIOS_COPY - Fast memory copy (LDDR version for overlapping)
; Input:  HL = Source, DE = Destination, BC = Count
; Output: None
;----------------------------------------------------------------------------
bios_copy:
    push    hl
    push    de
    push    bc

    ; Check if source < dest (overlapping case)
    ld      a, h
    cp      d
    jr      c, .copy_backwards
    jr      nz, .copy_forwards
    ld      a, l
    cp      e
    jr      c, .copy_backwards

.copy_forwards:
    ldir
    jr      .copy_done

.copy_backwards:
    ; Set up for LDDR (copy backwards)
    dec     bc
    add     hl, bc
    ex      de, hl
    add     hl, bc
    ex      de, hl
    inc     bc
    lddr

.copy_done:
    pop     bc
    pop     de
    pop     hl
    ret

;----------------------------------------------------------------------------
; BIOS_FILL - Fast memory fill
; Input:  HL = Start, BC = Count, A = Fill value
; Output: None
;----------------------------------------------------------------------------
bios_fill:
    push    hl
    push    bc
    push    de

    ld      (hl), a
    ld      d, h
    ld      e, l
    inc     de
    dec     bc
    ld      a, b
    or      c
    jr      z, .fill_done
    ldir

.fill_done:
    pop     de
    pop     bc
    pop     hl
    ret

;----------------------------------------------------------------------------
; Helper: Print null-terminated string
; Input:  HL = String pointer
;----------------------------------------------------------------------------
bios_print_string:
    push    af
    push    hl
.print_loop:
    ld      a, (hl)
    or      a
    jr      z, .print_done
    call    text_putc_raw
    inc     hl
    jr      .print_loop
.print_done:
    pop     hl
    pop     af
    ret

;----------------------------------------------------------------------------
; Helper: Print error message
; Input:  HL = Error string pointer
;----------------------------------------------------------------------------
bios_print_error:
    push    hl
    ld      hl, #error_prefix
    call    bios_print_string
    pop     hl
    call    bios_print_string
    ret

;----------------------------------------------------------------------------
; Helper: Raw text output (no cursor update)
; Input:  A = Character
;----------------------------------------------------------------------------
text_putc_raw:
    push    af
    push    bc
    push    de
    push    hl

    ; Write character to VRAM name table
    ; Simple implementation - assumes Screen 0 mode
    ld      c, a
    ld      a, (#SV_CURSOR_Y)
    ld      l, a
    ld      h, #0x00
    add     hl, hl
    add     hl, hl
    add     hl, hl
    add     hl, hl
    add     hl, hl              ; HL = Y * 32 (name table width)
    ld      a, (#SV_CURSOR_X)
    ld      e, a
    ld      d, #0x00
    add     hl, de              ; HL = Y * 32 + X
    ld      de, #0x3800         ; Name table base
    add     hl, de              ; HL = VRAM address

    ; Set VRAM address
    ld      a, l
    out     (#PORT_VRAM_ADDR), a
    ld      a, h
    or      #0x40               ; Write mode
    out     (#PORT_VRAM_ADDR), a

    ; Write character
    ld      a, c
    out     (#PORT_VRAM_DATA), a

    ; Update cursor position
    ld      a, (#SV_CURSOR_X)
    inc     a
    cp      #40                 ; 40 columns
    jr      c, .cursor_ok
    ld      a, #0x00
    ld      (#SV_CURSOR_X), a
    ld      a, (#SV_CURSOR_Y)
    inc     a
    cp      #24                 ; 24 rows
    jr      c, .cursor_y_ok
    ld      a, #0x00
.cursor_y_ok:
    ld      (#SV_CURSOR_Y), a
    jr      .putc_done

.cursor_ok:
    ld      (#SV_CURSOR_X), a

.putc_done:
    pop     hl
    pop     de
    pop     bc
    pop     af
    ret

;----------------------------------------------------------------------------
; VDP Hardware Initialization
;----------------------------------------------------------------------------
vdp_init_hw:
    push    af
    push    bc

    ; Register 0: Mode control 1
    ; Bit 7: Enable external video input
    ; Bit 6: M3 (mode bit 3)
    ; Bit 5: Enable interrupt
    ; Bit 4: M2 (mode bit 2)
    ; Bit 0: M4 (mode bit 4) - must be 0
    ld      a, #0x00
    call    vdp_write_reg_hw
    ld      a, #0x00            ; Register 0
    call    vdp_write_reg_hw

    ; Register 1: Mode control 2
    ; Bit 7: 4/16K selection (1 = 16K)
    ; Bit 6: Blank enable (1 = display on)
    ; Bit 5: IE1 (interrupt enable)
    ; Bit 4: M1 (mode bit 1)
    ; Bit 3: M3 (mode bit 3, same as reg 0 bit 6)
    ; Bit 1: Sprite size (0 = 8x8, 1 = 16x16)
    ; Bit 0: Sprite magnification (0 = 1x, 1 = 2x)
    ld      a, #0xC0            ; 16K VRAM, display on, interrupts on
    call    vdp_write_reg_hw
    ld      a, #0x01            ; Register 1
    call    vdp_write_reg_hw

    ; Register 2: Name table base address
    ; Value * 0x400 = actual address
    ; 0x0E * 0x400 = 0x3800
    ld      a, #0x0E
    call    vdp_write_reg_hw
    ld      a, #0x02            ; Register 2
    call    vdp_write_reg_hw

    ; Register 3: Color table base address
    ; (Screen 2 only) Value * 0x40 = actual address
    ld      a, #0x80            ; 0x80 * 0x40 = 0x2000
    call    vdp_write_reg_hw
    ld      a, #0x03            ; Register 3
    call    vdp_write_reg_hw

    ; Register 4: Pattern table base address
    ; (Screen 2 only) Value * 0x800 = actual address
    ld      a, #0x00            ; 0x00 * 0x800 = 0x0000
    call    vdp_write_reg_hw
    ld      a, #0x04            ; Register 4
    call    vdp_write_reg_hw

    ; Register 5: Sprite attribute table base
    ; Value * 0x80 = actual address
    ; 0x76 * 0x80 = 0x3B00
    ld      a, #0x76
    call    vdp_write_reg_hw
    ld      a, #0x05            ; Register 5
    call    vdp_write_reg_hw

    ; Register 6: Sprite pattern table base
    ; Value * 0x800 = actual address
    ; 0x03 * 0x800 = 0x1800
    ld      a, #0x03
    call    vdp_write_reg_hw
    ld      a, #0x06            ; Register 6
    call    vdp_write_reg_hw

    ; Register 7: Foreground/Background color
    ; Upper nibble = foreground, lower nibble = background
    ld      a, #0xF1            ; White on black
    call    vdp_write_reg_hw
    ld      a, #0x07            ; Register 7
    call    vdp_write_reg_hw

    ; Clear VRAM
    call    vdp_clear_vram

    pop     bc
    pop     af
    ret

;----------------------------------------------------------------------------
; VDP Write Register (hardware)
; Input:  A = Value, next A = Register number
;----------------------------------------------------------------------------
vdp_write_reg_hw:
    out     (#PORT_VDP_CMD), a
    ret

;----------------------------------------------------------------------------
; VDP Clear VRAM
;----------------------------------------------------------------------------
vdp_clear_vram:
    push    af
    push    bc
    push    de
    push    hl

    ; Set VRAM write address to 0
    xor     a
    out     (#PORT_VRAM_ADDR), a
    ld      a, #0x40            ; Write mode
    out     (#PORT_VRAM_ADDR), a

    ; Clear 16K VRAM with 0
    ld      bc, #0x4000         ; 16K
    xor     a
.clear_loop:
    out     (#PORT_VRAM_DATA), a
    dec     bc
    ld      d, a
    ld      a, b
    or      c
    ld      a, d
    jr      nz, .clear_loop

    pop     hl
    pop     de
    pop     bc
    pop     af
    ret

;----------------------------------------------------------------------------
; PSG Hardware Initialization
;----------------------------------------------------------------------------
psg_init_hw:
    push    af

    ; Mute all channels
    ld      a, #0x9F            ; Channel A volume = 0
    out     (#PORT_PSG), a
    ld      a, #0xBF            ; Channel B volume = 0
    out     (#PORT_PSG), a
    ld      a, #0xDF            ; Channel C volume = 0
    out     (#PORT_PSG), a
    ld      a, #0xFF            ; Noise volume = 0
    out     (#PORT_PSG), a

    ; Set mixer: all tones off, all noise off
    ld      a, #0x07
    out     (#PORT_PSG), a
    ld      a, #0x3F
    out     (#PORT_PSG), a

    pop     af
    ret

;----------------------------------------------------------------------------
; Cartridge Detection
; Output: Carry set if cartridge found
;----------------------------------------------------------------------------
cart_detect:
    push    af
    push    hl
    push    bc

    ; Check cartridge port for magic bytes
    in      a, (#PORT_CART)
    cp      #'A'
    jr      nz, .no_cart

    ; Additional checks would go here
    ; For now, assume cartridge present if 'A' detected
    scf
    jr      .cart_done

.no_cart:
    or      a                   ; Clear carry

.cart_done:
    pop     bc
    pop     hl
    pop     af
    ret

;----------------------------------------------------------------------------
; Cartridge Execute
;----------------------------------------------------------------------------
cart_execute:
    push    af
    push    hl

    ; Get cartridge entry point from system variables
    ld      hl, (#SV_CART_ROM_BASE)

    ; Jump to cartridge (will not return if successful)
    ; In real hardware, this would map cartridge ROM
    pop     hl
    pop     af
    ret

;----------------------------------------------------------------------------
; Keyboard Scan
;----------------------------------------------------------------------------
kbd_scan:
    push    af
    push    bc
    push    de
    push    hl

    ; Scan 8 rows of keyboard matrix
    ld      b, #8               ; 8 rows
    ld      c, #0x00            ; Row counter
    ld      hl, #kbd_matrix

.scan_row:
    ld      a, c
    out     (#PORT_KBD), a      ; Select row
    in      a, (#PORT_KBD)      ; Read columns
    ld      (hl), a             ; Store in matrix
    inc     hl
    inc     c
    djnz    .scan_row

    ; Process matrix changes
    call    kbd_process_matrix

    pop     hl
    pop     de
    pop     bc
    pop     af
    ret

; Keyboard matrix storage (8 bytes)
kbd_matrix:
    .ds     8

; Previous keyboard matrix
kbd_matrix_prev:
    .ds     8

;----------------------------------------------------------------------------
; Process Keyboard Matrix
;----------------------------------------------------------------------------
kbd_process_matrix:
    push    af
    push    bc
    push    de
    push    hl
    push    ix

    ld      ix, #kbd_matrix
    ld      hl, #kbd_matrix_prev
    ld      b, #8               ; 8 rows
    ld      c, #0x00            ; Row index

.proc_row:
    ld      a, (ix)
    ld      d, a                ; Current row
    ld      a, (hl)
    ld      e, a                ; Previous row
    inc     hl

    ; Find changed bits (XOR)
    ld      a, d
    xor     e
    jr      z, .next_row        ; No changes

    ; Process each bit
    ld      e, #8               ; 8 columns
    ld      d, #0x01            ; Bit mask

.proc_bit:
    ld      a, (ix)
    and     d
    jr      z, .check_release

    ; Key pressed
    push    af
    ld      a, c
    sla     a
    sla     a
    sla     a                   ; A = row * 8
    add     a, #8
    sub     e                   ; A = row * 8 + col
    call    kbd_buffer_put
    pop     af

.check_release:
    sla     d
    dec     e
    jr      nz, .proc_bit

.next_row:
    inc     ix
    inc     c
    djnz    .proc_row

    ; Copy current to previous
    ld      hl, #kbd_matrix
    ld      de, #kbd_matrix_prev
    ld      bc, #8
    ldir

    pop     ix
    pop     hl
    pop     de
    pop     bc
    pop     af
    ret

;----------------------------------------------------------------------------
; Put key in buffer
; Input:  A = Scancode
;----------------------------------------------------------------------------
kbd_buffer_put:
    push    af
    push    hl
    push    bc

    ; Get head and tail
    ld      hl, #0x0009         ; Head
    ld      b, (hl)
    inc     hl                  ; Tail
    ld      c, (hl)

    ; Check if buffer full
    inc     c
    ld      a, c
    and     #0x0F
    ld      c, a
    cp      b
    jr      z, .buffer_full     ; Full

    ; Store key
    dec     hl                  ; Back to head
    ld      a, b
    and     #0x0F
    add     a, #0x0B            ; Buffer data offset
    ld      l, a
    ld      h, #0x00
    pop     bc
    ld      (hl), c             ; Store scancode
    push    bc

    ; Increment head
    ld      hl, #0x0009
    inc     (hl)
    ld      a, (hl)
    and     #0x0F
    ld      (hl), a

.buffer_full:
    pop     bc
    pop     hl
    pop     af
    ret

;----------------------------------------------------------------------------
; Interrupt Vector Table
;----------------------------------------------------------------------------
    .org    0x8300

int_vector_table:
    .dw     INT_VBLANK          ; 0x00 - Vertical blank
    .dw     INT_KEYBOARD        ; 0x01 - Keyboard
    .dw     cart_insert_handler ; 0x02 - Cartridge insert
    .dw     INT_TIMER           ; 0x03 - Timer
    .dw     0x0000              ; 0x04 - Reserved
    .dw     0x0000              ; 0x05 - Reserved
    .dw     0x0000              ; 0x06 - Reserved
    .dw     0x0000              ; 0x07 - Reserved

;----------------------------------------------------------------------------
; Cartridge Insert Handler
;----------------------------------------------------------------------------
cart_insert_handler:
    push    af

    ; Set cartridge inserted flag
    ld      a, (#SV_FLAGS)
    or      #SYS_CART_INSERTED
    ld      (#SV_FLAGS), a

    pop     af
    ret

;----------------------------------------------------------------------------
; String Data
;----------------------------------------------------------------------------
boot_msg:
    .db     0x0C                ; Clear screen
    .ascii  "ASX Operating System"
    .db     0x0D, 0x0A
    .ascii  "Architecture for Synthesized eXchange"
    .db     0x0D, 0x0A
    .ascii  "Version 1.0.3"
    .db     0x0D, 0x0A
    .ascii  "(C) 1986 ASX Systems, Inc."
    .db     0x0D, 0x0A, 0x0D, 0x0A
    .ascii  "8K RAM detected and tested OK"
    .db     0x0D, 0x0A
    .ascii  "16K VRAM initialized"
    .db     0x0D, 0x0A
    .ascii  "No cartridge detected."
    .db     0x0D, 0x0A
    .ascii  "Loading ASX-BASIC..."
    .db     0x0D, 0x0A, 0x00

cart_boot_msg:
    .db     0x0C
    .ascii  "ASX Operating System"
    .db     0x0D, 0x0A
    .ascii  "Cartridge detected."
    .db     0x0D, 0x0A
    .ascii  "Executing cartridge..."
    .db     0x0D, 0x0A, 0x00

cart_return_msg:
    .ascii  "Cartridge returned."
    .db     0x0D, 0x0A
    .ascii  "Loading ASX-BASIC..."
    .db     0x0D, 0x0A, 0x00

ram_error_msg:
    .ascii  "RAM TEST FAILED"
    .db     0x00

error_prefix:
    .ascii  "ERROR: "
    .db     0x00

;----------------------------------------------------------------------------
; BIOS Padding to fill 16KB
;----------------------------------------------------------------------------
    .org    0xBFFF
    .db     0x00                ; Fill byte
