/*
 * ASX Keyboard Input Module
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * 8x8 keyboard matrix scanned via PORT_KEYBOARD
 * Supports buffered input with 16-character ring buffer
 */

#include "../asx.h"

/* ========================================================================
 * KEYBOARD MATRIX LAYOUT
 * ======================================================================== */

/*
 * Row 0:  ESC  1    2    3    4    5    6    7
 * Row 1:  8    9    0    -    =    BKSP TAB  Q
 * Row 2:  W    E    R    T    Y    U    I    O
 * Row 3:  P    [    ]    \   CTRL A    S    D
 * Row 4:  F    G    H    J    K    L    ;    '
 * Row 5:  `    LSHF Z    X    C    V    B    N
 * Row 6:  M    ,    .    /    RSHF *    ALT  SPC
 * Row 7:  CAPS F1   F2   F3   F4   F5   F6   F7
 * 
 * Shifted characters handled in software
 */

/* Scancode definitions */
#define SC_NONE     0x00
#define SC_ESC      0x00
#define SC_1        0x01
#define SC_2        0x02
#define SC_3        0x03
#define SC_4        0x04
#define SC_5        0x05
#define SC_6        0x06
#define SC_7        0x07
#define SC_8        0x08
#define SC_9        0x09
#define SC_0        0x0A
#define SC_MINUS    0x0B
#define SC_EQUAL    0x0C
#define SC_BACKSPACE 0x0D
#define SC_TAB      0x0E
#define SC_Q        0x0F
#define SC_W        0x10
#define SC_E        0x11
#define SC_R        0x12
#define SC_T        0x13
#define SC_Y        0x14
#define SC_U        0x15
#define SC_I        0x16
#define SC_O        0x17
#define SC_P        0x18
#define SC_LBRACKET 0x19
#define SC_RBRACKET 0x1A
#define SC_BACKSLASH 0x1B
#define SC_CTRL     0x1C
#define SC_A        0x1D
#define SC_S        0x1E
#define SC_D        0x1F
#define SC_F        0x20
#define SC_G        0x21
#define SC_H        0x22
#define SC_J        0x23
#define SC_K        0x24
#define SC_L        0x25
#define SC_SEMICOLON 0x26
#define SC_QUOTE    0x27
#define SC_GRAVE    0x28
#define SC_LSHIFT   0x29
#define SC_Z        0x2A
#define SC_X        0x2B
#define SC_C        0x2C
#define SC_V        0x2D
#define SC_B        0x2E
#define SC_N        0x2F
#define SC_M        0x30
#define SC_COMMA    0x31
#define SC_PERIOD   0x32
#define SC_SLASH    0x33
#define SC_RSHIFT   0x34
#define SC_ASTERISK 0x35
#define SC_ALT      0x36
#define SC_SPACE    0x37
#define SC_CAPS     0x38
#define SC_F1       0x39
#define SC_F2       0x3A
#define SC_F3       0x3B
#define SC_F4       0x3C
#define SC_F5       0x3D
#define SC_F6       0x3E
#define SC_F7       0x3F
#define SC_F8       0x40
#define SC_F9       0x41
#define SC_F10      0x42
#define SC_ENTER    0x43
#define SC_UP       0x44
#define SC_DOWN     0x45
#define SC_LEFT     0x46
#define SC_RIGHT    0x47
#define SC_HOME     0x48
#define SC_END      0x49
#define SC_PGUP     0x4A
#define SC_PGDN     0x4B
#define SC_INSERT   0x4C
#define SC_DELETE   0x4D

/* ========================================================================
 * INTERNAL STATE
 * ======================================================================== */

static byte kbd_buffer[KEY_BUFFER_SIZE];
static byte kbd_head = 0;
static byte kbd_tail = 0;
static byte shift_state = 0;
static byte ctrl_state = 0;
static byte caps_state = 0;
static byte kbd_matrix[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
static byte kbd_matrix_prev[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

/* ========================================================================
 * SCANCODES TO ASCII CONVERSION
 * ======================================================================== */

/* Unshifted ASCII lookup */
static const char scancode_to_ascii[128] = {
    /* 0x00-0x0F */
    0x1B, '1', '2', '3', '4', '5', '6', '7',
    '8', '9', '0', '-', '=', 0x08, 0x09, 'q',
    /* 0x10-0x1F */
    'w', 'e', 'r', 't', 'y', 'u', 'i', 'o',
    'p', '[', ']', '\', 0, 'a', 's', 'd',
    /* 0x20-0x2F */
    'f', 'g', 'h', 'j', 'k', 'l', ';', ''',
    '`', 0, 'z', 'x', 'c', 'v', 'b', 'n',
    /* 0x30-0x3F */
    'm', ',', '.', '/', 0, '*', 0, ' ',
    0, 0, 0, 0, 0, 0, 0, 0,
    /* 0x40-0x4F */
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    /* Rest */
    [SC_ENTER] = 0x0D,
    [SC_UP] = 0x80,
    [SC_DOWN] = 0x81,
    [SC_LEFT] = 0x82,
    [SC_RIGHT] = 0x83,
    [SC_HOME] = 0x84,
    [SC_END] = 0x85,
    [SC_PGUP] = 0x86,
    [SC_PGDN] = 0x87,
    [SC_INSERT] = 0x88,
    [SC_DELETE] = 0x89,
};

/* Shifted ASCII lookup */
static const char scancode_to_ascii_shifted[128] = {
    /* 0x00-0x0F */
    0x1B, '!', '@', '#', '$', '%', '^', '&',
    '*', '(', ')', '_', '+', 0x08, 0x09, 'Q',
    /* 0x10-0x1F */
    'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O',
    'P', '{', '}', '|', 0, 'A', 'S', 'D',
    /* 0x20-0x2F */
    'F', 'G', 'H', 'J', 'K', 'L', ':', '"',
    '~', 0, 'Z', 'X', 'C', 'V', 'B', 'N',
    /* 0x30-0x3F */
    'M', '<', '>', '?', 0, '*', 0, ' ',
    0, 0, 0, 0, 0, 0, 0, 0,
    /* Rest */
    [SC_ENTER] = 0x0D,
};

/* ========================================================================
 * INITIALIZATION
 * ======================================================================== */

void kbd_init(void) {
    byte i;

    /* Clear buffer */
    kbd_head = 0;
    kbd_tail = 0;
    for (i = 0; i < KEY_BUFFER_SIZE; i++) {
        kbd_buffer[i] = 0;
    }

    /* Reset state */
    shift_state = 0;
    ctrl_state = 0;
    caps_state = 0;

    /* Clear matrix */
    for (i = 0; i < 8; i++) {
        kbd_matrix[i] = 0xFF;
        kbd_matrix_prev[i] = 0xFF;
    }
}

/* ========================================================================
 * BUFFER OPERATIONS
 * ======================================================================== */

/* Check if buffer has data */
bool kbd_poll(void) {
    return kbd_head != kbd_tail;
}

/* Get character from buffer (blocking) */
char kbd_getc(void) {
    char c;

    /* Wait for key */
    while (!kbd_poll()) {
        /* Could yield or wait for interrupt here */
    }

    /* Read from buffer */
    c = kbd_buffer[kbd_tail];
    kbd_tail = (kbd_tail + 1) & (KEY_BUFFER_SIZE - 1);

    return c;
}

/* Check if specific scancode is currently pressed */
bool kbd_keydown(byte scancode) {
    byte row, col;
    byte mask;

    row = scancode >> 3;    /* Divide by 8 */
    col = scancode & 0x07;  /* Modulo 8 */
    mask = ~(1 << col);

    if (row < 8) {
        return (kbd_matrix[row] & mask) == 0;
    }

    return false;
}

/* Get raw scancode (non-blocking) */
byte kbd_get_scancode(void) {
    byte sc;

    if (!kbd_poll()) return 0;

    sc = kbd_buffer[kbd_tail];
    kbd_tail = (kbd_tail + 1) & (KEY_BUFFER_SIZE - 1);

    return sc;
}

/* ========================================================================
 * BUFFER MANAGEMENT
 * ======================================================================== */

/* Add scancode to buffer */
static void kbd_buffer_put(byte scancode) {
    byte next_head;

    next_head = (kbd_head + 1) & (KEY_BUFFER_SIZE - 1);

    /* Don't overwrite if buffer full */
    if (next_head == kbd_tail) return;

    kbd_buffer[kbd_head] = scancode;
    kbd_head = next_head;
}

/* ========================================================================
 * MATRIX SCANNING
 * ======================================================================== */

/* Scan the keyboard matrix */
void kbd_scan(void) {
    byte row;
    byte col;
    byte data;
    byte prev_data;
    byte changes;
    byte mask;
    byte scancode;

    /* Save previous state */
    for (row = 0; row < 8; row++) {
        kbd_matrix_prev[row] = kbd_matrix[row];
    }

    /* Scan each row */
    for (row = 0; row < 8; row++) {
        /* In real hardware: output row select to PORT_KEYBOARD */
        /* Read column data from PORT_KEYBOARD */
        /* For emulator, simulate based on input */

        /* Simulate: all keys released (0xFF = no keys pressed) */
        kbd_matrix[row] = 0xFF;
    }

    /* Process changes */
    for (row = 0; row < 8; row++) {
        data = kbd_matrix[row];
        prev_data = kbd_matrix_prev[row];
        changes = data ^ prev_data;

        if (changes == 0) continue;

        for (col = 0; col < 8; col++) {
            mask = 1 << col;

            if (changes & mask) {
                scancode = (row << 3) | col;

                if ((prev_data & mask) && !(data & mask)) {
                    /* Key pressed (transition from 1 to 0) */
                    kbd_process_keydown(scancode);
                } else if (!(prev_data & mask) && (data & mask)) {
                    /* Key released (transition from 0 to 1) */
                    kbd_process_keyup(scancode);
                }
            }
        }
    }
}

/* ========================================================================
 * KEY EVENT HANDLING
 * ======================================================================== */

/* Handle key press */
static void kbd_process_keydown(byte scancode) {
    /* Update modifier states */
    switch (scancode) {
        case SC_LSHIFT:
        case SC_RSHIFT:
            shift_state = 1;
            return;
        case SC_CTRL:
            ctrl_state = 1;
            return;
        case SC_ALT:
            /* Alt handling */
            return;
        case SC_CAPS:
            caps_state = !caps_state;
            return;
    }

    /* Add to buffer */
    kbd_buffer_put(scancode);
}

/* Handle key release */
static void kbd_process_keyup(byte scancode) {
    switch (scancode) {
        case SC_LSHIFT:
        case SC_RSHIFT:
            shift_state = 0;
            return;
        case SC_CTRL:
            ctrl_state = 0;
            return;
        case SC_ALT:
            /* Alt handling */
            return;
    }
}

/* ========================================================================
 * ASCII CONVERSION
 * ======================================================================== */

/* Convert scancode to ASCII character */
char kbd_scancode_to_ascii(byte scancode) {
    char c;
    int shift;

    if (scancode >= 128) return 0;

    /* Determine if shift is active */
    shift = shift_state;

    /* Caps lock affects letters */
    if (caps_state) {
        c = scancode_to_ascii[scancode];
        if (c >= 'a' && c <= 'z') {
            shift = !shift;
        }
    }

    if (shift) {
        c = scancode_to_ascii_shifted[scancode];
    } else {
        c = scancode_to_ascii[scancode];
    }

    /* Ctrl handling */
    if (ctrl_state && c >= 'a' && c <= 'z') {
        c = c - 'a' + 1;  /* Ctrl+A = 0x01, etc. */
    }

    return c;
}

/* Get ASCII character from buffer (blocking) */
char kbd_getchar(void) {
    byte scancode;
    char c;

    do {
        scancode = kbd_get_scancode();
    } while (scancode == 0);

    c = kbd_scancode_to_ascii(scancode);
    return c;
}

/* ========================================================================
 * SPECIAL KEY CHECKS
 * ======================================================================== */

bool kbd_shift_pressed(void) {
    return shift_state != 0;
}

bool kbd_ctrl_pressed(void) {
    return ctrl_state != 0;
}

bool kbd_caps_lock(void) {
    return caps_state != 0;
}

/* Flush keyboard buffer */
void kbd_flush(void) {
    kbd_head = 0;
    kbd_tail = 0;
}

/* Check buffer fill level */
byte kbd_buffer_count(void) {
    return (kbd_head - kbd_tail) & (KEY_BUFFER_SIZE - 1);
}
