/*
 * ASX Operating System - Main Entry Point
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * WebAssembly Interface:
 *   - asx_init(): Initialize system
 *   - asx_frame(): Execute one frame (called at 60Hz)
 *   - asx_keydown(scancode): Handle key press
 *   - asx_keyup(scancode): Handle key release
 *   - asx_load_cart(data, size): Load cartridge
 *   - asx_get_display(): Get VRAM display buffer
 *   - asx_get_vram(): Get full VRAM
 */

#include "asx.h"
#include <emscripten.h>

/* ========================================================================
 * SYSTEM MEMORY
 * ======================================================================== */

/* 8KB RAM */
byte ram[RAM_SIZE];

/* 16KB VRAM (separate address space) */
byte vram[VRAM_SIZE];

/* 32KB ROM (BIOS + BASIC) */
byte rom[ROM_SIZE];

/* System tick counter */
static volatile word system_ticks = 0;

/* Frame counter */
static word frame_count = 0;

/* ========================================================================
 * VRAM ACCESS HELPERS (for emulator)
 * ======================================================================== */

/* These override the inline functions in asx.h for the emulator */
byte vdp_read_vram(word addr) {
    return vram[addr & 0x3FFF];
}

void vdp_write_vram(word addr, byte data) {
    vram[addr & 0x3FFF] = data;
}

/* ========================================================================
 * KEYBOARD INTERFACE (from JavaScript)
 * ======================================================================== */

/* Keyboard matrix (8 rows x 8 columns) */
static byte keyboard_matrix[8] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

/* Scancode to matrix position mapping */
static const byte scancode_to_row[128] = {
    /* 0x00-0x0F */ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    /* 0x10-0x1F */ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    /* 0x20-0x2F */ 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 6,
    /* 0x30-0x3F */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 5, 0, 0, 0, 6,
    /* 0x40-0x4F */ 0, 3, 5, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 4, 4, 3,
    /* 0x50-0x5F */ 3, 1, 2, 2, 3, 4, 5, 5, 5, 6, 6, 3, 0, 3, 0, 5,
    /* 0x60-0x6F */ 0, 3, 5, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 4, 4, 3,
    /* 0x70-0x7F */ 3, 1, 2, 2, 3, 4, 5, 5, 5, 6, 6, 0, 0, 0, 0, 0,
};

static const byte scancode_to_col[128] = {
    /* 0x00-0x0F */ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    /* 0x10-0x1F */ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    /* 0x20-0x2F */ 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 2,
    /* 0x30-0x3F */ 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 0, 5, 0, 0, 0, 3,
    /* 0x40-0x4F */ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5,
    /* 0x50-0x5F */ 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 0, 7, 0, 5,
    /* 0x60-0x6F */ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5,
    /* 0x70-0x7F */ 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 0, 0, 0, 0, 0,
};

/* ========================================================================
 * EMSCRIPTEN EXPORTED FUNCTIONS
 * ======================================================================== */

/* Initialize the ASX system */
EMSCRIPTEN_KEEPALIVE
void asx_init(void) {
    /* Clear RAM */
    mem_set(ram, 0, RAM_SIZE);

    /* Clear VRAM */
    mem_set(vram, 0, VRAM_SIZE);

    /* Initialize subsystems */
    vdp_init(SCREEN_0);
    text_init();
    kbd_init();
    joy_init();
    psg_init();
    timer_init();
    basic_init();

    /* Print boot message */
    text_clear();
    text_puts("ASX Operating System
");
    text_puts("Architecture for Synthesized eXchange
");
    text_puts("Version 1.0.3
");
    text_puts("(C) 1986 ASX Systems, Inc.
");
    text_puts("
");
    text_puts("8K RAM detected and tested OK
");
    text_puts("16K VRAM initialized
");
    text_puts("No cartridge detected.
");
    text_puts("Loading ASX-BASIC...
");
    text_puts("
");

    system_ticks = 0;
    frame_count = 0;
}

/* Execute one frame (called at 60Hz) */
EMSCRIPTEN_KEEPALIVE
void asx_frame(void) {
    system_ticks++;
    frame_count++;

    /* Update timer */
    timer_tick();

    /* Process keyboard */
    /* kbd_scan(); */

    /* Update joystick */
    /* joy_update(); */

    /* Call VBlank handler if registered */
    /* In real system, this would trigger the interrupt */
}

/* Handle key press from JavaScript */
EMSCRIPTEN_KEEPALIVE
void asx_keydown(byte scancode) {
    byte row, col;

    if (scancode >= 128) return;

    row = scancode_to_row[scancode];
    col = scancode_to_col[scancode];

    if (row < 8 && col > 0 && col <= 8) {
        keyboard_matrix[row] &= ~(1 << (col - 1));
    }

    /* Also add to keyboard buffer for buffered input */
    {
        byte ascii = kbd_scancode_to_ascii(scancode);
        if (ascii != 0) {
            /* Add to buffer */
        }
    }
}

/* Handle key release from JavaScript */
EMSCRIPTEN_KEEPALIVE
void asx_keyup(byte scancode) {
    byte row, col;

    if (scancode >= 128) return;

    row = scancode_to_row[scancode];
    col = scancode_to_col[scancode];

    if (row < 8 && col > 0 && col <= 8) {
        keyboard_matrix[row] |= (1 << (col - 1));
    }
}

/* Load cartridge from data */
EMSCRIPTEN_KEEPALIVE
int asx_load_cart(const byte* data, int size) {
    if (cart_insert(data, (word)size)) {
        text_puts("Cartridge loaded.
");

        if (cart_get_flags() & CART_FLAG_AUTO_RUN) {
            cart_execute();
        }

        return 1;
    }

    text_puts("Invalid cartridge.
");
    return 0;
}

/* Get VRAM display buffer pointer */
EMSCRIPTEN_KEEPALIVE
byte* asx_get_vram(void) {
    return vram;
}

/* Get VRAM size */
EMSCRIPTEN_KEEPALIVE
int asx_get_vram_size(void) {
    return VRAM_SIZE;
}

/* Get display width */
EMSCRIPTEN_KEEPALIVE
int asx_get_width(void) {
    return DISP_WIDTH;
}

/* Get display height */
EMSCRIPTEN_KEEPALIVE
int asx_get_height(void) {
    return DISP_HEIGHT;
}

/* Get current screen mode */
EMSCRIPTEN_KEEPALIVE
int asx_get_screen_mode(void) {
    return 0;  /* Would read from system vars */
}

/* Set joystick state */
EMSCRIPTEN_KEEPALIVE
void asx_joy_set(byte port, byte state) {
    joy_set_state(port, state);
}

/* Get system tick count */
EMSCRIPTEN_KEEPALIVE
word asx_get_ticks(void) {
    return system_ticks;
}

/* Reset system */
EMSCRIPTEN_KEEPALIVE
void asx_reset(void) {
    asx_init();
}

/* Execute BASIC command */
EMSCRIPTEN_KEEPALIVE
void asx_basic_cmd(const char* cmd) {
    basic_execute(cmd);
}

/* Get text output buffer */
EMSCRIPTEN_KEEPALIVE
const char* asx_get_output(void) {
    /* Return pointer to text output buffer */
    return (const char*)ram;
}

/* ========================================================================
 * MAIN ENTRY POINT
 * ======================================================================== */

int main(int argc, char* argv[]) {
    (void)argc;
    (void)argv;

    asx_init();

    /* Enter main loop */
    /* In browser, asx_frame() is called from JavaScript */

    return 0;
}
