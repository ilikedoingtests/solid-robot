/*
 * ASX Block Graphics Module - Screen 3
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * Screen 3: 64x48 blocks, each block is 4x4 pixels
 * Total resolution: 256x192 pixels (same display area)
 * 
 * In Screen 3 mode:
 *   - Pattern table defines the block patterns
 *   - Color table defines colors for each block
 *   - Name table selects which pattern/color combo
 *   - Each character cell = 2x2 blocks = 8x8 pixels
 *   - 32x24 character grid = 64x48 blocks
 */

#include "../asx.h"

/* ========================================================================
 * CONSTANTS
 * ======================================================================== */

#define BLOCK_COLS      64
#define BLOCK_ROWS      48
#define BLOCK_SIZE_PX   4
#define CHAR_COLS       32
#define CHAR_ROWS       24
#define BLOCKS_PER_CHAR 4       /* 2x2 blocks per character */

/* ========================================================================
 * INTERNAL HELPERS
 * ======================================================================== */

/* Convert block coordinates to character cell */
static void block_to_char(byte block_col, byte block_row, 
                           byte* char_col, byte* char_row,
                           byte* block_in_char) {
    *char_col = block_col / 2;
    *char_row = block_row / 2;
    *block_in_char = (block_row % 2) * 2 + (block_col % 2);
}

/* Get pattern and color addresses for a block */
static void get_block_addrs(byte block_col, byte block_row,
                            word* pat_addr, word* col_addr, word* name_addr) {
    byte char_col, char_row, block_in_char;
    word char_num;

    block_to_char(block_col, block_row, &char_col, &char_row, &block_in_char);

    char_num = (word)char_row * CHAR_COLS + char_col;

    /* In Screen 3, pattern table is at 0x0000, color at 0x2000 */
    /* Each character has 8 bytes in pattern table */
    *pat_addr = (word)char_num * 8;
    *col_addr = 0x2000 + (word)char_num * 8;
    *name_addr = 0x3800 + char_num;
}

/* ========================================================================
 * INITIALIZATION
 * ======================================================================== */

void block_init(void) {
    word i;

    /* Set Screen 3 mode */
    vdp_set_mode(SCREEN_3);

    /* Clear pattern table */
    for (i = 0; i < 0x1800; i++) {
        vdp_write_vram(i, 0x00);
    }

    /* Clear color table */
    for (i = 0x2000; i < 0x3800; i++) {
        vdp_write_vram(i, 0x01);  /* Black */
    }

    /* Initialize name table */
    for (i = 0; i < 768; i++) {
        vdp_write_vram(0x3800 + i, (byte)(i & 0xFF));
    }
}

/* ========================================================================
 * SCREEN CLEARING
 * ======================================================================== */

void block_clear(byte color) {
    word i;
    byte color_byte;

    color_byte = (color << 4) | (color & 0x0F);

    /* Clear all blocks to specified color */
    for (i = 0x2000; i < 0x3800; i++) {
        vdp_write_vram(i, color_byte);
    }

    /* Clear pattern table */
    for (i = 0; i < 0x1800; i++) {
        vdp_write_vram(i, 0x00);
    }
}

/* ========================================================================
 * BLOCK OPERATIONS
 * ======================================================================== */

void block_put(byte col, byte row, byte color) {
    word pat_addr, col_addr, name_addr;
    byte char_col, char_row, block_in_char;
    byte pattern_byte, color_byte;
    byte row_in_char;
    byte mask;

    if (col >= BLOCK_COLS || row >= BLOCK_ROWS) return;

    /* Get addresses */
    get_block_addrs(col, row, &pat_addr, &col_addr, &name_addr);

    /* Determine which 2x2 block within the character */
    block_to_char(col, row, &char_col, &char_row, &block_in_char);

    /* Each block is 4x4 pixels within an 8x8 character */
    /* Block layout in character:
     *   0 = top-left (pixels 0-3, rows 0-3)
     *   1 = top-right (pixels 4-7, rows 0-3)
     *   2 = bottom-left (pixels 0-3, rows 4-7)
     *   3 = bottom-right (pixels 4-7, rows 4-7)
     */

    /* For each of the 4 rows in this block */
    for (row_in_char = 0; row_in_char < 4; row_in_char++) {
        word actual_pat_addr, actual_col_addr;
        byte actual_row;

        actual_row = (block_in_char / 2) * 4 + row_in_char;
        actual_pat_addr = pat_addr + actual_row;
        actual_col_addr = col_addr + actual_row;

        /* Read current pattern and color */
        pattern_byte = vdp_read_vram(actual_pat_addr);
        color_byte = vdp_read_vram(actual_col_addr);

        /* Set the appropriate 4 bits */
        if (block_in_char % 2 == 0) {
            /* Left half: bits 7-4 */
            mask = 0xF0;
            pattern_byte = (pattern_byte & ~mask) | 0xF0;  /* Set all 4 bits */
            color_byte = (color_byte & 0x0F) | (color << 4);
        } else {
            /* Right half: bits 3-0 */
            mask = 0x0F;
            pattern_byte = (pattern_byte & ~mask) | 0x0F;  /* Set all 4 bits */
            color_byte = (color_byte & 0xF0) | (color & 0x0F);
        }

        vdp_write_vram(actual_pat_addr, pattern_byte);
        vdp_write_vram(actual_col_addr, color_byte);
    }
}

byte block_get(byte col, byte row) {
    word pat_addr, col_addr, name_addr;
    byte block_in_char;
    byte color_byte;

    if (col >= BLOCK_COLS || row >= BLOCK_ROWS) return 0;

    get_block_addrs(col, row, &pat_addr, &col_addr, &name_addr);
    block_to_char(col, row, &col, &row, &block_in_char);

    /* Read color from first row of the block */
    color_byte = vdp_read_vram(col_addr + (block_in_char / 2) * 4);

    if (block_in_char % 2 == 0) {
        return color_byte >> 4;
    } else {
        return color_byte & 0x0F;
    }
}

/* ========================================================================
 * RECTANGLE FILL
 * ======================================================================== */

void block_fill_rect(byte col, byte row, byte w, byte h, byte color) {
    byte i, j;
    byte end_col, end_row;

    if (w == 0 || h == 0) return;

    end_col = col + w;
    end_row = row + h;

    if (end_col > BLOCK_COLS) end_col = BLOCK_COLS;
    if (end_row > BLOCK_ROWS) end_row = BLOCK_ROWS;

    for (j = row; j < end_row; j++) {
        for (i = col; i < end_col; i++) {
            block_put(i, j, color);
        }
    }
}

/* ========================================================================
 * LINE DRAWING (Block-based)
 * ======================================================================== */

void block_line(byte c1, byte r1, byte c2, byte r2, byte color) {
    sword dx, dy;
    sword sx, sy;
    sword err, e2;

    dx = (c2 > c1) ? (sword)(c2 - c1) : (sword)(c1 - c2);
    dy = (c2 > c1) ? (sword)(r2 - r1) : (sword)(r1 - r2);

    sx = (c1 < c2) ? 1 : -1;
    sy = (r1 < r2) ? 1 : -1;

    err = dx - dy;

    for (;;) {
        block_put(c1, r1, color);

        if (c1 == c2 && r1 == r2) break;

        e2 = 2 * err;

        if (e2 > -dy) {
            err -= dy;
            c1 = (byte)((sword)c1 + sx);
        }

        if (e2 < dx) {
            err += dx;
            r1 = (byte)((sword)r1 + sy);
        }
    }
}

/* ========================================================================
 * UTILITY
 * ======================================================================== */

/* Get display width in blocks */
byte block_width(void) {
    return BLOCK_COLS;
}

/* Get display height in blocks */
byte block_height(void) {
    return BLOCK_ROWS;
}

/* Convert pixel coordinates to block coordinates */
void pixel_to_block(byte px, byte py, byte* col, byte* row) {
    *col = px / BLOCK_SIZE_PX;
    *row = py / BLOCK_SIZE_PX;
}

/* Convert block coordinates to pixel coordinates */
void block_to_pixel(byte col, byte row, byte* px, byte* py) {
    *px = col * BLOCK_SIZE_PX;
    *py = row * BLOCK_SIZE_PX;
}
