/*
 * ASX Sample Cartridge - Demo Program
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * This cartridge demonstrates ASX-BASIC capabilities:
 *   - Graphics modes
 *   - Sound
 *   - Sprite movement
 *   - Text output
 */

#include "../asx.h"

/* Sample BASIC program as cartridge ROM */
static const char* demo_program[] = {
    "10 REM ASX DEMO CARTRIDGE",
    "20 REM (C) 1986 ASX Systems",
    "30 CLS",
    "40 PRINT "ASX OPERATING SYSTEM"",
    "50 PRINT "DEMO CARTRIDGE"",
    "60 PRINT """,
    "70 PRINT "Testing graphics..."",
    "80 SCREEN 2",
    "90 COLOR 15,1",
    "100 FOR I=0 TO 255 STEP 4",
    "110 PSET I,10,2",
    "120 PSET I,20,3",
    "130 PSET I,30,4",
    "140 PSET I,40,5",
    "150 NEXT I",
    "160 FOR I=0 TO 15",
    "170 LINE I*16,50,I*16+15,65,I",
    "180 NEXT I",
    "190 CIRCLE 128,120,40,6",
    "200 CIRCLE 128,120,30,7",
    "210 CIRCLE 128,120,20,8",
    "220 LINE 0,0,255,191,15",
    "230 LINE 255,0,0,191,15",
    "240 BEEP",
    "250 FOR D=1 TO 1000: NEXT D",
    "260 SCREEN 3",
    "270 FOR Y=0 TO 47",
    "280 FOR X=0 TO 63",
    "290 C=(X+Y) MOD 16",
    "300 REM BLOCK X,Y,C",
    "310 NEXT X",
    "320 NEXT Y",
    "330 BEEP",
    "340 FOR D=1 TO 1000: NEXT D",
    "350 SCREEN 0",
    "360 CLS",
    "370 PRINT "DEMO COMPLETE"",
    "380 PRINT """,
    "390 PRINT "ASX-BASIC v1.0"",
    "400 PRINT "8K RAM / 16K VRAM"",
    "410 PRINT "256x192 Display"",
    "420 PRINT "3-Channel PSG"",
    "430 END",
    0
};

/* Build cartridge data */
static byte cart_rom[4096];
static word cart_rom_size = 0;

/* Build the cartridge */
void build_demo_cart(byte* output, word* out_size) {
    cart_header_t hdr;
    word offset = 0;
    word line_num = 10;
    word i;
    const char* line;
    word line_len;
    word prog_size = 0;
    byte prog_buffer[2048];

    /* Build BASIC program data */
    for (i = 0; demo_program[i] != 0; i++) {
        line = demo_program[i];
        line_len = str_length(line);

        /* Line number (2 bytes, Little-Endian) */
        prog_buffer[prog_size++] = (byte)(line_num & 0xFF);
        prog_buffer[prog_size++] = (byte)(line_num >> 8);

        /* Line length */
        prog_buffer[prog_size++] = (byte)line_len;

        /* Line text */
        {
            word j;
            for (j = 0; j < line_len; j++) {
                prog_buffer[prog_size++] = (byte)line[j];
            }
        }

        line_num += 10;
    }

    /* End marker */
    prog_buffer[prog_size++] = 0;
    prog_buffer[prog_size++] = 0;
    prog_buffer[prog_size++] = 0;

    /* Create header */
    hdr.magic[0] = CART_MAGIC_0;
    hdr.magic[1] = CART_MAGIC_1;
    hdr.magic[2] = CART_MAGIC_2;
    hdr.magic[3] = CART_MAGIC_3;
    hdr.version = 0x01;
    hdr.flags = CART_FLAG_HAS_BASIC | CART_FLAG_AUTO_RUN;
    write_word((byte*)&hdr.rom_size, prog_size);
    write_word((byte*)&hdr.ram_size, 0);
    write_word((byte*)&hdr.entry_point, 0);
    write_word((byte*)&hdr.checksum, 0);
    hdr.reserved[0] = 0;
    hdr.reserved[1] = 0;

    /* Write header */
    for (i = 0; i < CART_HDR_SIZE; i++) {
        output[offset++] = ((byte*)&hdr)[i];
    }

    /* Write program */
    for (i = 0; i < prog_size; i++) {
        output[offset++] = prog_buffer[i];
    }

    *out_size = offset;
}

/* Export as binary file */
void export_demo_cart(const char* filename) {
    byte cart[4096];
    word size;

    build_demo_cart(cart, &size);

    /* In real build, write to file */
    /* For now, just store in global */
    mem_copy(cart_rom, cart, size);
    cart_rom_size = size;
}
