/*
 * ASX Sound Module - PSG (Programmable Sound Generator)
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * Based on Texas Instruments SN76489 / Yamaha YM2149 PSG
 * 3 tone channels + 1 noise channel
 * 4-bit volume control per channel
 */

#include "../asx.h"

/* ========================================================================
 * PSG REGISTER DEFINITIONS
 * ======================================================================== */

/* Tone channel frequencies (10-bit, split into coarse and fine) */
#define PSG_CHA_TONE    0x00    /* Channel A tone (bits 9-8 = coarse, 7-0 = fine) */
#define PSG_CHB_TONE    0x02    /* Channel B tone */
#define PSG_CHC_TONE    0x04    /* Channel C tone */
#define PSG_NOISE       0x06    /* Noise control */
#define PSG_MIXER       0x07    /* Mixer / enable control */
#define PSG_CHA_VOL     0x08    /* Channel A volume */
#define PSG_CHB_VOL     0x09    /* Channel B volume */
#define PSG_CHC_VOL     0x0A    /* Channel C volume */
#define PSG_NOISE_VOL   0x0F    /* Noise volume */

/* Noise control bits */
#define NOISE_FREQ_MASK 0x03    /* Frequency control */
#define NOISE_PERIODIC  0x04    /* Periodic noise (0 = white, 1 = periodic) */

/* Mixer bits (0 = enable, 1 = disable) */
#define MIXER_TONE_A    0x01
#define MIXER_TONE_B    0x02
#define MIXER_TONE_C    0x04
#define MIXER_NOISE_A   0x08
#define MIXER_NOISE_B   0x10
#define MIXER_NOISE_C   0x20
#define MIXER_IO_B      0x40    /* I/O port B direction */
#define MIXER_IO_A      0x80    /* I/O port A direction */

/* ========================================================================
 * INTERNAL STATE
 * ======================================================================== */

static byte psg_regs[16];       /* Cached PSG register values */
static word tone_freq[3];       /* Current tone frequencies */
static byte tone_vol[3];        /* Current tone volumes */
static byte noise_mode;         /* Current noise mode */
static byte noise_vol;          /* Current noise volume */

/* Note frequency table (A4 = 440Hz, equal temperament)
 * Values are PSG period counts for 3.58MHz clock
 * Formula: count = clock / (32 * frequency)
 */
static const word note_freqs[12] = {
    /* C    C#   D    D#   E    F    F#   G    G#   A    A#   B  */
    3822, 3608, 3405, 3214, 3034, 2863, 2703, 2551, 2408, 2273, 2145, 2025
};

/* ========================================================================
 * LOW-LEVEL PSG ACCESS
 * ======================================================================== */

/* Write to PSG register */
static void psg_write(byte reg, byte value) {
    psg_regs[reg] = value;
    /* In real hardware:
     * out (PORT_PSG), value
     * The PSG latches the register from the upper bits
     */
}

/* ========================================================================
 * INITIALIZATION
 * ======================================================================== */

void psg_init(void) {
    byte i;

    /* Mute all channels */
    psg_write(PSG_CHA_VOL, 0x00);
    psg_write(PSG_CHB_VOL, 0x00);
    psg_write(PSG_CHC_VOL, 0x00);
    psg_write(PSG_NOISE_VOL, 0x00);

    /* Disable all tone and noise outputs */
    psg_write(PSG_MIXER, 0x3F);

    /* Reset frequencies */
    psg_write(PSG_CHA_TONE, 0x00);
    psg_write(PSG_CHA_TONE + 1, 0x00);
    psg_write(PSG_CHB_TONE, 0x00);
    psg_write(PSG_CHB_TONE + 1, 0x00);
    psg_write(PSG_CHC_TONE, 0x00);
    psg_write(PSG_CHC_TONE + 1, 0x00);

    /* Reset noise */
    psg_write(PSG_NOISE, 0x00);

    /* Clear state */
    for (i = 0; i < 3; i++) {
        tone_freq[i] = 0;
        tone_vol[i] = 0;
    }
    noise_mode = 0;
    noise_vol = 0;
}

/* ========================================================================
 * TONE CONTROL
 * ======================================================================== */

/* Set tone frequency for a channel */
void psg_tone(byte channel, word frequency) {
    byte reg_base;
    byte coarse, fine;

    if (channel > 2) return;

    /* Calculate PSG period count */
    /* count = 3579545 / (32 * frequency) */
    /* For simplicity, use pre-calculated or approximate */

    if (frequency == 0) {
        coarse = 0;
        fine = 0;
    } else {
        word count = 111861 / frequency;  /* 3579545 / 32 ≈ 111861 */
        if (count > 1023) count = 1023;
        coarse = (count >> 8) & 0x0F;
        fine = count & 0xFF;
    }

    reg_base = channel * 2;

    /* Write coarse (upper 4 bits in register data) */
    psg_write(reg_base, (coarse << 4) | 0x00);  /* Register select + coarse */
    /* Write fine */
    psg_write(reg_base, fine);  /* Fine value */

    tone_freq[channel] = frequency;
}

/* Set volume for a channel (0-15, 0 = max, 15 = silent) */
void psg_volume(byte channel, byte volume) {
    byte reg;

    if (channel > 2) return;
    if (volume > 15) volume = 15;

    reg = PSG_CHA_VOL + channel;
    psg_write(reg, volume & 0x0F);

    tone_vol[channel] = volume;
}

/* ========================================================================
 * NOISE CONTROL
 * ======================================================================== */

/* Set noise mode */
void psg_noise(byte mode) {
    psg_write(PSG_NOISE, mode & 0x07);
    noise_mode = mode;
}

/* Set noise volume */
void psg_noise_vol(byte volume) {
    if (volume > 15) volume = 15;
    psg_write(PSG_NOISE_VOL, volume & 0x0F);
    noise_vol = volume;
}

/* ========================================================================
 * MIXER CONTROL
 * ======================================================================== */

/* Enable/disable tone on a channel */
void psg_tone_enable(byte channel, bool enable) {
    byte mixer;

    mixer = psg_regs[PSG_MIXER];

    if (enable) {
        mixer &= ~(MIXER_TONE_A << channel);
    } else {
        mixer |= (MIXER_TONE_A << channel);
    }

    psg_write(PSG_MIXER, mixer);
}

/* Enable/disable noise on a channel */
void psg_noise_enable(byte channel, bool enable) {
    byte mixer;

    mixer = psg_regs[PSG_MIXER];

    if (enable) {
        mixer &= ~(MIXER_NOISE_A << channel);
    } else {
        mixer |= (MIXER_NOISE_A << channel);
    }

    psg_write(PSG_MIXER, mixer);
}

/* Mute all channels */
void psg_mute_all(void) {
    psg_write(PSG_CHA_VOL, 0x0F);
    psg_write(PSG_CHB_VOL, 0x0F);
    psg_write(PSG_CHC_VOL, 0x0F);
    psg_write(PSG_NOISE_VOL, 0x0F);
}

/* ========================================================================
 * HIGH-LEVEL MUSIC FUNCTIONS
 * ======================================================================== */

/* Play a note on a channel */
void psg_play_note(byte channel, word freq, byte vol, word duration) {
    if (channel > 2) return;

    psg_tone(channel, freq);
    psg_volume(channel, vol);
    psg_tone_enable(channel, true);

    /* Duration is in milliseconds (approximate) */
    /* In real system, would set up timer interrupt */
    timer_delay(duration);

    psg_tone_enable(channel, false);
}

/* Stop a channel */
void psg_stop(byte channel) {
    if (channel > 2) return;
    psg_tone_enable(channel, false);
    psg_volume(channel, 0x0F);  /* Mute */
}

/* Stop all channels */
void psg_stop_all(void) {
    psg_stop(0);
    psg_stop(1);
    psg_stop(2);
    psg_noise_vol(0x0F);
}

/* ========================================================================
 * NOTE FREQUENCY LOOKUP
 * ======================================================================== */

/* Get frequency for a note (octave 0-7, note 0-11) */
word psg_note_freq(byte octave, byte note) {
    word freq;

    if (note > 11) note = 11;
    if (octave > 7) octave = 7;

    freq = note_freqs[note];

    /* Adjust for octave */
    /* freq = base_freq / (2 ^ octave) */
    while (octave > 0) {
        freq >>= 1;
        octave--;
    }

    return freq;
}

/* Play a musical note */
void psg_play_musical_note(byte channel, byte octave, byte note, byte vol, word duration) {
    word freq = psg_note_freq(octave, note);
    psg_play_note(channel, freq, vol, duration);
}

/* ========================================================================
 * SOUND EFFECTS
 * ======================================================================== */

/* Simple beep */
void psg_beep(void) {
    psg_play_note(0, 1000, 8, 100);
}

/* Click sound */
void psg_click(void) {
    psg_play_note(0, 2000, 4, 20);
}

/* Error buzz */
void psg_error(void) {
    psg_play_note(0, 200, 12, 300);
}

/* Success chime */
void psg_success(void) {
    psg_play_note(0, 880, 8, 100);
    timer_delay(50);
    psg_play_note(0, 1100, 8, 200);
}

/* Startup sound */
void psg_startup(void) {
    psg_play_note(0, 523, 10, 100);  /* C5 */
    timer_delay(50);
    psg_play_note(1, 659, 10, 100);  /* E5 */
    timer_delay(50);
    psg_play_note(2, 784, 10, 200);  /* G5 */
}

/* ========================================================================
 * ENVELOPE / EFFECTS (Simplified)
 * ======================================================================== */

/* Fade volume over time */
void psg_fade(byte channel, byte start_vol, byte end_vol, word steps, word step_time) {
    byte vol;
    sword delta;
    sword current;
    word i;

    if (channel > 2) return;
    if (steps == 0) return;

    delta = ((sword)end_vol - (sword)start_vol) * 256 / steps;
    current = (sword)start_vol * 256;

    for (i = 0; i < steps; i++) {
        vol = (byte)(current / 256);
        if (vol > 15) vol = 15;
        psg_volume(channel, vol);
        timer_delay(step_time);
        current += delta;
    }

    psg_volume(channel, end_vol);
}

/* Tremolo effect */
void psg_tremolo(byte channel, word base_freq, byte depth, word rate, word duration) {
    word elapsed = 0;
    sword offset;
    word freq;

    while (elapsed < duration) {
        offset = (sword)(depth * math_sin(elapsed * rate / 100));
        freq = (word)((sword)base_freq + offset);
        if (freq < 100) freq = 100;
        psg_tone(channel, freq);
        timer_delay(10);
        elapsed += 10;
    }
}

/* Simple sine approximation for effects */
sword math_sin(word angle) {
    /* Simplified sine using lookup or approximation */
    /* angle is in degrees * 10 (0-3600) */
    sword result;

    angle = angle % 3600;
    if (angle < 0) angle += 3600;

    /* Very rough approximation */
    if (angle <= 900) {
        result = (angle * 256) / 900;
    } else if (angle <= 1800) {
        result = 256 - ((angle - 900) * 256) / 900;
    } else if (angle <= 2700) {
        result = -((angle - 1800) * 256) / 900;
    } else {
        result = -256 + ((angle - 2700) * 256) / 900;
    }

    return result;
}
