/*
 * ASX Operating System
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 * 
 * SYSTEM SPECIFICATIONS:
 *   Total Storage: 1 MB (0x000000 - 0x0FFFFF)
 *   Endianness: Little-Endian (LSB first)
 *   RAM: 8 KB (0x0000 - 0x1FFF)
 *   ROM: 32 KB (0x8000 - 0xFFFF)
 *     - BIOS: 0x8000 - 0xBFFF (16 KB)
 *     - BASIC: 0xC000 - 0xFFFF (16 KB)
 *   VRAM: 16 KB (separate address space, mapped at 0x0000 - 0x3FFF)
 *   Display: 256 x 192 pixels max
 *   Clock: 3.58 MHz Z80-compatible core
 */

#ifndef ASX_H
#define ASX_H

#include <stdint.h>
#include <stdbool.h>

/* ========================================================================
 * MEMORY MAP - Little-Endian throughout
 * ======================================================================== */

/* RAM Layout (8 KB total: 0x0000 - 0x1FFF) */
#define RAM_BASE        0x0000
#define RAM_SIZE        0x2000      /* 8192 bytes */
#define RAM_TOP         0x1FFF

/* RAM Sub-allocations */
#define RAM_SYSTEM      0x0000      /* 256 bytes system variables */
#define RAM_STACK_TOP   0x1FFF      /* Stack grows downward from here */
#define RAM_USER_BASE   0x0100      /* User program space starts here */
#define RAM_BASIC_VARS  0x1800      /* BASIC variable storage */
#define RAM_BUFFER      0x1E00      /* 512 byte general buffer */

/* ROM Layout (32 KB total: 0x8000 - 0xFFFF) */
#define ROM_BASE        0x8000
#define ROM_SIZE        0x8000      /* 32768 bytes */
#define ROM_BIOS_BASE   0x8000      /* BIOS starts here */
#define ROM_BIOS_SIZE   0x4000      /* 16384 bytes */
#define ROM_BASIC_BASE  0xC000      /* BASIC starts here */
#define ROM_BASIC_SIZE  0x4000      /* 16384 bytes */

/* VRAM Layout (16 KB: separate address space 0x0000 - 0x3FFF) */
#define VRAM_BASE       0x0000
#define VRAM_SIZE       0x4000      /* 16384 bytes */

/* VRAM Sub-allocations */
#define VRAM_PATTERN    0x0000      /* Pattern table (Screen 2: 6144 bytes) */
#define VRAM_COLOR      0x2000      /* Color table (Screen 2: 6144 bytes) */
#define VRAM_NAME       0x3800      /* Name table (768 bytes) */
#define VRAM_SPRITE_ATTR 0x3B00     /* Sprite attribute table (128 bytes) */
#define VRAM_SPRITE_PAT 0x3C00      /* Sprite pattern table (2048 bytes) */
#define VRAM_FONT       0x0000      /* Font data (Screen 0/1, 2048 bytes) */

/* I/O Ports */
#define PORT_VRAM_ADDR  0x98        /* VRAM address write (2 bytes, LSB first) */
#define PORT_VRAM_DATA  0x98        /* VRAM data read/write */
#define PORT_VDP_CMD    0x99        /* VDP command/status register */
#define PORT_PSG        0xA0        /* Programmable Sound Generator */
#define PORT_JOYSTICK_1 0xA8        /* Joystick 1 */
#define PORT_JOYSTICK_2 0xA9        /* Joystick 2 */
#define PORT_KEYBOARD   0xAA        /* Keyboard matrix */
#define PORT_CART_CTRL  0xAB        /* Cartridge control */

/* ========================================================================
 * VIDEO DISPLAY MODES
 * ======================================================================== */

/* Screen Mode Register Values */
#define SCREEN_0        0x00        /* Standard Text: 40x24, monochrome */
#define SCREEN_1        0x01        /* Mixed Text & Sprites: 32x24 */
#define SCREEN_2        0x02        /* High-Resolution Graphics: 256x192 */
#define SCREEN_3        0x03        /* Low-Resolution Blocks: 64x48 (4x4 blocks) */

/* Display Dimensions */
#define DISP_WIDTH      256
#define DISP_HEIGHT     192
#define TEXT_COLS_40    40
#define TEXT_ROWS_24    24
#define TEXT_COLS_32    32
#define TEXT_ROWS_32    24
#define BLOCK_COLS      64
#define BLOCK_ROWS      48
#define BLOCK_SIZE      4           /* 4x4 pixel blocks in Screen 3 */

/* Colors (16-color palette, TMS9918 compatible) */
#define COL_TRANSPARENT 0x00
#define COL_BLACK       0x01
#define COL_MEDIUM_GREEN 0x02
#define COL_LIGHT_GREEN 0x03
#define COL_DARK_BLUE   0x04
#define COL_LIGHT_BLUE  0x05
#define COL_DARK_RED    0x06
#define COL_CYAN        0x07
#define COL_MEDIUM_RED  0x08
#define COL_LIGHT_RED   0x09
#define COL_DARK_YELLOW 0x0A
#define COL_LIGHT_YELLOW 0x0B
#define COL_DARK_GREEN  0x0C
#define COL_MAGENTA     0x0D
#define COL_GRAY        0x0E
#define COL_WHITE       0x0F

/* ========================================================================
 * SYSTEM VARIABLES (stored in RAM 0x0000 - 0x00FF)
 * ======================================================================== */

/* System state flags */
#define SYS_CART_INSERTED   0x01
#define SYS_BASIC_ACTIVE    0x02
#define SYS_INT_ENABLED     0x04
#define SYS_KEY_PRESSED     0x08

/* System variable offsets in RAM */
#define SV_FLAGS            0x0000  /* System flags byte */
#define SV_CURR_SCREEN      0x0001  /* Current screen mode */
#define SV_CURSOR_X         0x0002  /* Text cursor X */
#define SV_CURSOR_Y         0x0003  /* Text cursor Y */
#define SV_CURSOR_ATTR      0x0004  /* Cursor attributes */
#define SV_FG_COLOR         0x0005  /* Foreground color */
#define SV_BG_COLOR         0x0006  /* Background color */
#define SV_TICK_COUNT       0x0007  /* 16-bit tick counter (2 bytes) */
#define SV_KEY_BUFFER       0x0009  /* Keyboard buffer head */
#define SV_KEY_BUFFER_TAIL  0x000A  /* Keyboard buffer tail */
#define SV_KEY_BUFFER_DATA  0x000B  /* 16-byte keyboard buffer */
#define SV_JOY1_STATE       0x001B  /* Joystick 1 state */
#define SV_JOY2_STATE       0x001C  /* Joystick 2 state */
#define SV_CART_ROM_BASE    0x001D  /* Cartridge ROM base (2 bytes) */
#define SV_CART_ROM_SIZE    0x001F  /* Cartridge ROM size (2 bytes) */
#define SV_BASIC_PC         0x0021  /* BASIC program counter (2 bytes) */
#define SV_BASIC_SP         0x0023  /* BASIC stack pointer (2 bytes) */
#define SV_BASIC_VT_BASE    0x0025  /* BASIC variable table base (2 bytes) */
#define SV_BASIC_LINE_NUM   0x0027  /* Current BASIC line number (2 bytes) */
#define SV_VDP_STATUS       0x0029  /* VDP status register cache */
#define SV_INT_COUNTER      0x002A  /* Interrupt counter */

/* Keyboard buffer size */
#define KEY_BUFFER_SIZE     16

/* ========================================================================
 * CARTRIDGE FORMAT (.asx)
 * ======================================================================== */

/* ASX Cartridge Header (16 bytes, Little-Endian) */
#define CART_MAGIC_0        'A'
#define CART_MAGIC_1        'S'
#define CART_MAGIC_2        'X'
#define CART_MAGIC_3        0x1A    /* EOF marker */

#define CART_HDR_SIZE       16

/* Cartridge flags */
#define CART_FLAG_HAS_ROM   0x01
#define CART_FLAG_HAS_RAM   0x02
#define CART_FLAG_HAS_BASIC 0x04
#define CART_FLAG_AUTO_RUN  0x80

/* ========================================================================
 * INTERRUPT VECTORS
 * ======================================================================== */

#define INT_VBLANK          0x00    /* Vertical blank interrupt */
#define INT_KEYBOARD        0x01    /* Keyboard interrupt */
#define INT_CART_INSERT     0x02    /* Cartridge insert interrupt */
#define INT_TIMER           0x03    /* Timer interrupt */

/* ========================================================================
 * TYPE DEFINITIONS
 * ======================================================================== */

typedef uint8_t  byte;
typedef uint16_t word;
typedef uint32_t dword;
typedef int8_t   sbyte;
typedef int16_t  sword;

/* 16-bit register pair (Little-Endian storage) */
typedef union {
    word w;
    struct {
        byte l;     /* Low byte (LSB) */
        byte h;     /* High byte (MSB) */
    } b;
} reg16_t;

/* Cartridge header structure */
typedef struct __attribute__((packed)) {
    byte magic[4];          /* "ASX" */
    byte version;           /* Format version */
    byte flags;             /* Cartridge flags */
    word rom_size;          /* ROM size in bytes */
    word ram_size;          /* RAM size in bytes */
    word entry_point;       /* Entry point address */
    word checksum;          /* Simple checksum */
    byte reserved[2];       /* Reserved */
} cart_header_t;

/* Sprite attribute structure */
typedef struct __attribute__((packed)) {
    byte y;                 /* Y coordinate */
    byte x;                 /* X coordinate */
    byte pattern;           /* Pattern number */
    byte color;             /* Color & early clock */
} sprite_attr_t;

/* ========================================================================
 * INLINE HELPER FUNCTIONS
 * ======================================================================== */

/* Read a 16-bit value from memory (Little-Endian) */
static inline word read_word(byte* addr) {
    return (word)addr[0] | ((word)addr[1] << 8);
}

/* Write a 16-bit value to memory (Little-Endian) */
static inline void write_word(byte* addr, word val) {
    addr[0] = val & 0xFF;
    addr[1] = (val >> 8) & 0xFF;
}

/* ========================================================================
 * FUNCTION PROTOTYPES
 * ======================================================================== */

/* BIOS Functions */
void bios_init(void);
void bios_interrupt(byte vector);
byte bios_in(byte port);
void bios_out(byte port, byte value);
void bios_halt(void);

/* VDP / Video Functions */
void vdp_init(byte mode);
void vdp_set_mode(byte mode);
void vdp_write_vram(word addr, byte data);
byte vdp_read_vram(word addr);
void vdp_write_reg(byte reg, byte value);
byte vdp_read_status(void);
void vdp_wait_vblank(void);
void vdp_set_color(byte fg, byte bg);

/* Text Output Functions */
void text_init(void);
void text_clear(void);
void text_putc(char c);
void text_puts(const char* str);
void text_goto(byte x, byte y);
void text_scroll(void);
void text_set_color(byte fg, byte bg);

/* Graphics Functions */
void gfx_init(void);
void gfx_clear(byte color);
void gfx_plot(byte x, byte y, byte color);
void gfx_line(byte x1, byte y1, byte x2, byte y2, byte color);
void gfx_rect(byte x, byte y, byte w, byte h, byte color);
void gfx_fill_rect(byte x, byte y, byte w, byte h, byte color);
void gfx_put_pixel(byte x, byte y, byte color);
byte gfx_get_pixel(byte x, byte y);

/* Sprite Functions */
void sprite_init(void);
void sprite_set(byte num, byte x, byte y, byte pattern, byte color);
void sprite_hide(byte num);
void sprite_pattern(byte num, const byte* data);

/* Block Graphics (Screen 3) */
void block_init(void);
void block_clear(byte color);
void block_put(byte col, byte row, byte color);
byte block_get(byte col, byte row);

/* Keyboard Functions */
void kbd_init(void);
bool kbd_poll(void);
char kbd_getc(void);
bool kbd_keydown(byte scancode);
byte kbd_get_scancode(void);

/* Joystick Functions */
void joy_init(void);
byte joy_read(byte port);
bool joy_button(byte port, byte button);

/* Sound Functions */
void psg_init(void);
void psg_tone(byte channel, word frequency);
void psg_volume(byte channel, byte volume);
void psg_noise(byte mode);
void psg_play_note(byte channel, word freq, byte vol, word duration);

/* Cartridge Functions */
bool cart_insert(const byte* data, word size);
bool cart_remove(void);
bool cart_execute(void);
bool cart_validate(const byte* data, word size);

/* BASIC Interpreter Functions */
void basic_init(void);
void basic_run(void);
void basic_prompt(void);
bool basic_execute(const char* line);
void basic_list(void);
void basic_new(void);
void basic_load(const byte* data, word size);
void basic_save(byte* buffer, word* size);

/* Memory Management */
void* mem_alloc(word size);
void mem_free(void* ptr);
void mem_copy(byte* dst, const byte* src, word count);
void mem_set(byte* dst, byte value, word count);
word mem_compare(const byte* a, const byte* b, word count);

/* String Utilities */
word str_length(const char* str);
void str_copy(char* dst, const char* src);
word str_compare(const char* a, const char* b);
word str_to_word(const char* str);
void word_to_str(word val, char* buf);
void byte_to_hex(byte val, char* buf);

/* Math Utilities */
word math_abs(sword val);
word math_sqrt(word val);
word math_rand(void);
void math_srand(word seed);

/* Timer */
word timer_get(void);
void timer_delay(word ms);

/* System */
void sys_reset(void);
void sys_reboot(void);
word sys_version(void);

#endif /* ASX_H */
