/*
 * ASX Sprite Module
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * Supports up to 32 sprites (TMS9918A compatible)
 * Each sprite: 8x8 or 16x16 pixels, 1 color + transparent
 * Sprite attributes stored at VRAM 0x3B00-0x3B7F
 * Sprite patterns stored at VRAM 0x1800-0x1FFF
 */

#include "../asx.h"

/* ========================================================================
 * CONSTANTS
 * ======================================================================== */

#define MAX_SPRITES         32
#define SPRITE_ATTR_SIZE    4       /* bytes per sprite attribute */
#define SPRITE_PATTERN_SIZE 8       /* bytes per 8x8 pattern */

/* Sprite attribute offsets within attribute entry */
#define ATTR_Y              0
#define ATTR_X              1
#define ATTR_PATTERN        2
#define ATTR_COLOR          3

/* Early clock bit (shifts sprite left 32 pixels) */
#define SPRITE_EC           0x80

/* ========================================================================
 * SPRITE INITIALIZATION
 * ======================================================================== */

void sprite_init(void) {
    byte i;
    word attr_addr;

    /* Hide all sprites by setting Y = 208 (off-screen) */
    for (i = 0; i < MAX_SPRITES; i++) {
        attr_addr = VRAM_SPRITE_ATTR + (word)i * SPRITE_ATTR_SIZE;
        vdp_write_vram(attr_addr + ATTR_Y, 208);       /* Off-screen */
        vdp_write_vram(attr_addr + ATTR_X, 0);
        vdp_write_vram(attr_addr + ATTR_PATTERN, 0);
        vdp_write_vram(attr_addr + ATTR_COLOR, 0);
    }

    /* Clear sprite pattern table */
    for (i = 0; i < 0x800; i++) {
        vdp_write_vram(VRAM_SPRITE_PAT + i, 0x00);
    }
}

/* ========================================================================
 * SPRITE CONTROL
 * ======================================================================== */

void sprite_set(byte num, byte x, byte y, byte pattern, byte color) {
    word attr_addr;
    byte color_byte;

    if (num >= MAX_SPRITES) return;

    attr_addr = VRAM_SPRITE_ATTR + (word)num * SPRITE_ATTR_SIZE;

    /* Y coordinate: 208 = off-screen, 207 = last visible line */
    /* Note: Y+1 is actual display position (TMS9918 quirk) */
    vdp_write_vram(attr_addr + ATTR_Y, y);
    vdp_write_vram(attr_addr + ATTR_X, x);
    vdp_write_vram(attr_addr + ATTR_PATTERN, pattern);

    /* Color byte: upper bit = early clock, lower 4 bits = color */
    color_byte = color & 0x0F;
    vdp_write_vram(attr_addr + ATTR_COLOR, color_byte);
}

void sprite_hide(byte num) {
    word attr_addr;

    if (num >= MAX_SPRITES) return;

    attr_addr = VRAM_SPRITE_ATTR + (word)num * SPRITE_ATTR_SIZE;
    vdp_write_vram(attr_addr + ATTR_Y, 208);  /* Off-screen */
}

void sprite_move(byte num, byte x, byte y) {
    word attr_addr;

    if (num >= MAX_SPRITES) return;

    attr_addr = VRAM_SPRITE_ATTR + (word)num * SPRITE_ATTR_SIZE;
    vdp_write_vram(attr_addr + ATTR_Y, y);
    vdp_write_vram(attr_addr + ATTR_X, x);
}

void sprite_set_color(byte num, byte color) {
    word attr_addr;

    if (num >= MAX_SPRITES) return;

    attr_addr = VRAM_SPRITE_ATTR + (word)num * SPRITE_ATTR_SIZE;
    vdp_write_vram(attr_addr + ATTR_COLOR, color & 0x0F);
}

void sprite_set_pattern(byte num, byte pattern) {
    word attr_addr;

    if (num >= MAX_SPRITES) return;

    attr_addr = VRAM_SPRITE_ATTR + (word)num * SPRITE_ATTR_SIZE;
    vdp_write_vram(attr_addr + ATTR_PATTERN, pattern);
}

/* ========================================================================
 * SPRITE PATTERN DEFINITION
 * ======================================================================== */

void sprite_pattern(byte num, const byte* data) {
    word pat_addr;
    byte i;

    if (num >= 256) return;  /* 256 patterns max */

    pat_addr = VRAM_SPRITE_PAT + (word)num * SPRITE_PATTERN_SIZE;

    for (i = 0; i < SPRITE_PATTERN_SIZE; i++) {
        vdp_write_vram(pat_addr + i, data[i]);
    }
}

/* Define a 16x16 sprite pattern (uses 4 consecutive 8x8 patterns) */
void sprite_pattern_16x16(byte num, const byte* data) {
    word pat_addr;
    byte i;

    if (num >= 64) return;  /* 64 16x16 patterns max (uses 4 8x8 slots each) */

    pat_addr = VRAM_SPRITE_PAT + (word)num * 4 * SPRITE_PATTERN_SIZE;

    for (i = 0; i < 32; i++) {  /* 32 bytes for 16x16 */
        vdp_write_vram(pat_addr + i, data[i]);
    }
}

/* ========================================================================
 * SPRITE BATCH OPERATIONS
 * ======================================================================== */

void sprite_hide_all(void) {
    byte i;

    for (i = 0; i < MAX_SPRITES; i++) {
        sprite_hide(i);
    }
}

void sprite_update_all(const sprite_attr_t* attrs, byte count) {
    byte i;
    word attr_addr;

    if (count > MAX_SPRITES) count = MAX_SPRITES;

    for (i = 0; i < count; i++) {
        attr_addr = VRAM_SPRITE_ATTR + (word)i * SPRITE_ATTR_SIZE;
        vdp_write_vram(attr_addr + ATTR_Y, attrs[i].y);
        vdp_write_vram(attr_addr + ATTR_X, attrs[i].x);
        vdp_write_vram(attr_addr + ATTR_PATTERN, attrs[i].pattern);
        vdp_write_vram(attr_addr + ATTR_COLOR, attrs[i].color & 0x0F);
    }
}

/* ========================================================================
 * SPRITE COLLISION DETECTION
 * ======================================================================== */

/* Check if two sprites overlap */
byte sprite_collision(byte s1, byte s2) {
    word a1, a2;
    byte x1, y1, x2, y2;

    if (s1 >= MAX_SPRITES || s2 >= MAX_SPRITES) return 0;

    a1 = VRAM_SPRITE_ATTR + (word)s1 * SPRITE_ATTR_SIZE;
    a2 = VRAM_SPRITE_ATTR + (word)s2 * SPRITE_ATTR_SIZE;

    y1 = vdp_read_vram(a1 + ATTR_Y);
    x1 = vdp_read_vram(a1 + ATTR_X);
    y2 = vdp_read_vram(a2 + ATTR_Y);
    x2 = vdp_read_vram(a2 + ATTR_X);

    /* Simple AABB collision (8x8 sprites) */
    if (x1 < x2 + 8 && x1 + 8 > x2 &&
        y1 < y2 + 8 && y1 + 8 > y2) {
        return 1;
    }

    return 0;
}

/* Check VDP collision flag (5th sprite or sprite collision) */
byte sprite_check_vdp_collision(void) {
    byte status = vdp_read_status();
    return (status & 0x20) ? 1 : 0;  /* Collision bit */
}

/* Check for 5th sprite on same line */
byte sprite_check_5th(void) {
    byte status = vdp_read_status();
    return (status & 0x40) ? 1 : 0;  /* 5th sprite bit */
}

/* ========================================================================
 * UTILITY PATTERNS
 * ======================================================================== */

/* Common sprite patterns */
const byte SPRITE_PATTERN_BALL[8] = {
    0x3C, 0x7E, 0xFF, 0xFF, 0xFF, 0xFF, 0x7E, 0x3C
};

const byte SPRITE_PATTERN_ARROW_UP[8] = {
    0x18, 0x3C, 0x7E, 0xFF, 0x18, 0x18, 0x18, 0x18
};

const byte SPRITE_PATTERN_ARROW_DOWN[8] = {
    0x18, 0x18, 0x18, 0x18, 0xFF, 0x7E, 0x3C, 0x18
};

const byte SPRITE_PATTERN_ARROW_LEFT[8] = {
    0x10, 0x30, 0x70, 0xFF, 0xFF, 0x70, 0x30, 0x10
};

const byte SPRITE_PATTERN_ARROW_RIGHT[8] = {
    0x08, 0x0C, 0x0E, 0xFF, 0xFF, 0x0E, 0x0C, 0x08
};

const byte SPRITE_PATTERN_BOX[8] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

const byte SPRITE_PATTERN_CROSS[8] = {
    0x18, 0x18, 0x18, 0xFF, 0xFF, 0x18, 0x18, 0x18
};

const byte SPRITE_PATTERN_DIAMOND[8] = {
    0x18, 0x3C, 0x7E, 0xFF, 0xFF, 0x7E, 0x3C, 0x18
};

/* Load common patterns into sprite pattern table */
void sprite_load_common_patterns(void) {
    sprite_pattern(0, SPRITE_PATTERN_BALL);
    sprite_pattern(1, SPRITE_PATTERN_ARROW_UP);
    sprite_pattern(2, SPRITE_PATTERN_ARROW_DOWN);
    sprite_pattern(3, SPRITE_PATTERN_ARROW_LEFT);
    sprite_pattern(4, SPRITE_PATTERN_ARROW_RIGHT);
    sprite_pattern(5, SPRITE_PATTERN_BOX);
    sprite_pattern(6, SPRITE_PATTERN_CROSS);
    sprite_pattern(7, SPRITE_PATTERN_DIAMOND);
}
