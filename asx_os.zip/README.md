# ASX Operating System
## Architecture for Synthesized eXchange
### Version 1.0.3 - (C) 1986 ASX Systems, Inc.

---

## Overview

ASX is a complete 8-bit microcomputer operating system designed with the
aesthetics and constraints of 1980s home computers. It features a full
BASIC interpreter, four video modes, sprite hardware, programmable sound,
and a cartridge-based software distribution system.

## System Specifications

| Component | Specification |
|-----------|---------------|
| CPU | Z80-Compatible @ 3.58 MHz |
| RAM | 8 KB (0x0000 - 0x1FFF) |
| ROM | 32 KB (BIOS 16K + BASIC 16K) |
| VRAM | 16 KB (Separate Address Space) |
| Display | 256 x 192 pixels, 16 colors |
| Sound | PSG: 3 Tone + 1 Noise Channel |
| Input | Keyboard Matrix + 2 Joysticks |
| Storage | Cartridge (.asx format) |
| Endianness | Little-Endian (LSB First) |

## Memory Map

```
0x0000 - 0x00FF   System Variables (256 bytes)
0x0100 - 0x17FF   User Program Space (6 KB)
0x1800 - 0x1DFF   BASIC Variable Storage (1.5 KB)
0x1E00 - 0x1FFF   General Buffer (512 bytes)

0x4000 - 0x7FFF   Cartridge ROM Space (16 KB)

0x8000 - 0xBFFF   BIOS ROM (16 KB)
0xC000 - 0xFFFF   BASIC ROM (16 KB)

VRAM (Separate 16KB):
0x0000 - 0x17FF   Pattern Table (Screen 2)
0x1800 - 0x1FFF   Sprite Pattern Table
0x2000 - 0x37FF   Color Table (Screen 2)
0x3800 - 0x3AFF   Name Table
0x3B00 - 0x3B7F   Sprite Attribute Table
0x3B80 - 0x3FFF   Unused
```

## Video Display Modes

### Screen 0 - Standard Text (40x24)
- 40 columns x 24 rows
- Monochrome text with configurable foreground/background
- Uses built-in 8x8 font
- 6 pixels wide per character (256/40 = 6.4, truncated)

### Screen 1 - Mixed Text & Sprites (32x24)
- 32 columns x 24 rows
- 8x8 pixel characters
- Full 32 sprite support
- 16-color foreground/background per character group

### Screen 2 - High-Resolution Graphics (256x192)
- Full 256x192 pixel resolution
- 16 colors per 8-pixel line within each 8x8 cell
- 3 independent pattern/color zones
- Bitmap-addressable via PSET, PRESET, LINE, CIRCLE

### Screen 3 - Low-Resolution Blocks (64x48)
- 64 columns x 48 rows of 4x4 pixel blocks
- Each block is a single color
- Fast block fill operations
- Ideal for games and UI elements

## Color Palette (TMS9918A Compatible)

| Index | Name | RGB |
|-------|------|-----|
| 0 | Transparent | (0, 0, 0) |
| 1 | Black | (0, 0, 0) |
| 2 | Medium Green | (33, 200, 66) |
| 3 | Light Green | (94, 222, 127) |
| 4 | Dark Blue | (84, 85, 237) |
| 5 | Light Blue | (125, 118, 252) |
| 6 | Dark Red | (212, 82, 77) |
| 7 | Cyan | (66, 235, 245) |
| 8 | Medium Red | (252, 85, 84) |
| 9 | Light Red | (255, 121, 120) |
| 10 | Dark Yellow | (212, 193, 84) |
| 11 | Light Yellow | (230, 206, 128) |
| 12 | Dark Green | (33, 176, 59) |
| 13 | Magenta | (201, 91, 186) |
| 14 | Gray | (204, 204, 204) |
| 15 | White | (255, 255, 255) |

## ASX-BASIC Language

### Commands
- `REM` - Comment
- `LET` - Variable assignment (optional)
- `PRINT` - Output text/expressions
- `INPUT` - Read user input
- `IF...THEN` - Conditional execution
- `GOTO` - Unconditional jump
- `GOSUB...RETURN` - Subroutine call
- `FOR...TO...STEP...NEXT` - Loop construct
- `END` / `STOP` - Program termination

### Graphics
- `SCREEN mode` - Set display mode (0-3)
- `COLOR fg,bg` - Set colors
- `CLS` - Clear screen
- `PSET x,y,color` - Set pixel
- `PRESET x,y` - Clear pixel
- `LINE x1,y1,x2,y2,color` - Draw line
- `CIRCLE cx,cy,r,color` - Draw circle

### Sound
- `BEEP` - Generate beep
- `SOUND freq,duration` - Play tone

### System
- `LIST` - List program
- `RUN` - Execute program
- `NEW` - Clear program
- `CLEAR` - Clear variables
- `LOAD` / `SAVE` - Cartridge I/O
- `CONT` - Continue after STOP

### Functions
- `ABS(x)` - Absolute value
- `INT(x)` - Integer part
- `RND(x)` - Random number
- `SQR(x)` - Square root
- `PEEK(addr)` - Read memory
- `POKE addr,value` - Write memory
- `LEN(s$)` - String length

## Cartridge Format (.asx)

```
Offset  Size  Description
0x00    4     Magic: "ASX"
0x04    1     Version (0x01)
0x05    1     Flags
              bit 0: Has ROM
              bit 1: Has RAM
              bit 2: Has BASIC
              bit 7: Auto-run
0x06    2     ROM size (Little-Endian)
0x08    2     RAM size (Little-Endian)
0x0A    2     Entry point (Little-Endian)
0x0C    2     Checksum (Little-Endian)
0x0E    2     Reserved
0x10    N     ROM data
```

## Building

### Prerequisites
- Emscripten SDK
- Make
- Python 3 (for local server)

### Build Commands
```bash
# Build WebAssembly module
make

# Clean build artifacts
make clean

# Rebuild from scratch
make rebuild

# Start local development server
make serve
```

### Manual Compilation
```bash
emcc -O2 -s WASM=1   -s EXPORTED_FUNCTIONS='["_asx_init","_asx_frame","_asx_keydown","_asx_keyup","_asx_load_cart","_asx_get_vram","_main"]'   -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap"]'   -s INITIAL_MEMORY=1048576   -s STACK_SIZE=8192   src/*.c src/video/*.c src/kernel/*.c src/cartridge/*.c src/basic/*.c   -o www/asx.js
```

## File Structure

```
asx_os/
├── src/
│   ├── asx.h              # System header and constants
│   ├── main.c             # Entry point and WASM interface
│   ├── bios/
│   │   └── bios.asm       # BIOS assembly (16KB)
│   ├── video/
│   │   ├── vdp.c          # VDP driver
│   │   ├── text.c         # Text output (Screen 0/1)
│   │   ├── graphics.c     # Graphics (Screen 2)
│   │   ├── sprite.c       # Sprite system
│   │   └── block.c        # Block graphics (Screen 3)
│   ├── kernel/
│   │   ├── keyboard.c     # Keyboard input
│   │   ├── joystick.c     # Joystick input
│   │   ├── sound.c        # PSG sound
│   │   ├── memory.c       # Heap allocator
│   │   ├── utils.c        # String/math utilities
│   │   ├── timer.c        # Timer/delay
│   │   └── system.c       # System control
│   ├── cartridge/
│   │   ├── cart.c         # Cartridge loader
│   │   └── demo_cart.c    # Sample cartridge
│   └── basic/
│       └── basic.c        # BASIC interpreter
├── www/
│   └── index.html         # Web frontend
├── carts/                 # Cartridge files
├── build/                 # Build artifacts
├── Makefile
└── README.md
```

## Keyboard Controls

Click the display to capture keyboard focus.

| Key | Function |
|-----|----------|
| Alphanumeric | Standard input |
| Enter | Execute / New line |
| Backspace | Delete character |
| Escape | Break / Cancel |
| Arrow Keys | Directional input |
| F1-F10 | Function keys |

## Joystick Mapping

Standard 9-pin Atari-style joystick:
- Up/Down/Left/Right: Directional
- Button A: Fire 1
- Button B: Fire 2

## License

(C) 1986 ASX Systems, Inc. All Rights Reserved.

This is a fictional retro computing project created for educational
and entertainment purposes. The ASX Operating System does not represent
a real commercial product from 1986.

## Acknowledgments

- TMS9918A VDP reference design
- Z80 architecture documentation
- MSX standard specifications
- Classic 8-bit BASIC dialects
