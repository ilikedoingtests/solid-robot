/*
 * ASX Memory Management Module
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * Simple heap allocator for 8KB RAM
 * Uses first-fit allocation with block headers
 */

#include "../asx.h"

/* ========================================================================
 * HEAP STRUCTURE
 * ======================================================================== */

/* Memory block header (4 bytes, Little-Endian) */
#define BLOCK_FREE      0x00
#define BLOCK_USED      0x01
#define BLOCK_GUARD     0xA5    /* Guard byte for corruption detection */

typedef struct __attribute__((packed)) {
    word size;          /* Total block size including header */
    byte flags;         /* BLOCK_FREE or BLOCK_USED */
    byte guard;         /* BLOCK_GUARD */
} block_header_t;

#define HEADER_SIZE     sizeof(block_header_t)
#define MIN_ALLOC       4       /* Minimum allocation size */

/* ========================================================================
 * HEAP CONFIGURATION
 * ======================================================================== */

#define HEAP_BASE       RAM_USER_BASE   /* 0x0100 */
#define HEAP_TOP        (RAM_BASIC_VARS - 1)  /* 0x17FF */
#define HEAP_SIZE       (HEAP_TOP - HEAP_BASE + 1)

/* ========================================================================
 * INTERNAL STATE
 * ======================================================================== */

static byte* heap_base = (byte*)HEAP_BASE;
static word heap_size = HEAP_SIZE;
static byte heap_initialized = 0;

/* ========================================================================
 * HEAP INITIALIZATION
 * ======================================================================== */

static void heap_init(void) {
    block_header_t* first;

    if (heap_initialized) return;

    /* Create initial free block spanning entire heap */
    first = (block_header_t*)heap_base;
    first->size = heap_size;
    first->flags = BLOCK_FREE;
    first->guard = BLOCK_GUARD;

    heap_initialized = 1;
}

/* ========================================================================
 * MEMORY ALLOCATION
 * ======================================================================== */

void* mem_alloc(word size) {
    block_header_t* block;
    block_header_t* new_block;
    byte* ptr;
    word block_size;
    word remaining;

    if (size == 0) return 0;

    /* Align size to word boundary */
    if (size & 1) size++;

    /* Ensure minimum size */
    if (size < MIN_ALLOC) size = MIN_ALLOC;

    /* Initialize heap if needed */
    if (!heap_initialized) heap_init();

    /* Search for first-fit free block */
    ptr = heap_base;

    while (ptr < heap_base + heap_size) {
        block = (block_header_t*)ptr;

        /* Check guard byte */
        if (block->guard != BLOCK_GUARD) {
            /* Heap corruption detected */
            return 0;
        }

        if (block->flags == BLOCK_FREE && block->size >= size + HEADER_SIZE) {
            /* Found suitable block */
            block_size = block->size;

            /* Split block if there's enough remaining space */
            remaining = block_size - size - HEADER_SIZE;

            if (remaining >= HEADER_SIZE + MIN_ALLOC) {
                /* Split: create new free block after allocated portion */
                block->size = size + HEADER_SIZE;
                block->flags = BLOCK_USED;

                new_block = (block_header_t*)(ptr + block->size);
                new_block->size = remaining;
                new_block->flags = BLOCK_FREE;
                new_block->guard = BLOCK_GUARD;
            } else {
                /* Use entire block */
                block->flags = BLOCK_USED;
            }

            /* Return pointer to data area (after header) */
            return (void*)(ptr + HEADER_SIZE);
        }

        /* Move to next block */
        ptr += block->size;
    }

    /* No suitable block found */
    return 0;
}

/* ========================================================================
 * MEMORY DEALLOCATION
 * ======================================================================== */

void mem_free(void* ptr) {
    block_header_t* block;
    block_header_t* next;
    byte* bptr;

    if (ptr == 0) return;

    bptr = (byte*)ptr - HEADER_SIZE;
    block = (block_header_t*)bptr;

    /* Validate block */
    if (block->guard != BLOCK_GUARD) return;
    if (block->flags != BLOCK_USED) return;

    /* Mark as free */
    block->flags = BLOCK_FREE;

    /* Coalesce with next block if it's free */
    next = (block_header_t*)(bptr + block->size);

    if ((byte*)next < heap_base + heap_size && 
        next->guard == BLOCK_GUARD && next->flags == BLOCK_FREE) {
        /* Merge with next block */
        block->size += next->size;
    }

    /* Note: Coalescing with previous block would require
     * a doubly-linked list or backward scan. For simplicity,
     * we only coalesce forward. Fragmentation is handled
     * by periodic compaction (not implemented in v1.0).
     */
}

/* ========================================================================
 * MEMORY UTILITIES
 * ======================================================================== */

/* Copy memory (handles overlapping regions) */
void mem_copy(byte* dst, const byte* src, word count) {
    word i;

    if (dst == src || count == 0) return;

    if (dst < src) {
        /* Forward copy */
        for (i = 0; i < count; i++) {
            dst[i] = src[i];
        }
    } else {
        /* Backward copy for overlapping */
        for (i = count; i > 0; i--) {
            dst[i - 1] = src[i - 1];
        }
    }
}

/* Fill memory with value */
void mem_set(byte* dst, byte value, word count) {
    word i;

    for (i = 0; i < count; i++) {
        dst[i] = value;
    }
}

/* Compare memory regions */
word mem_compare(const byte* a, const byte* b, word count) {
    word i;

    for (i = 0; i < count; i++) {
        if (a[i] != b[i]) {
            return (word)(a[i] - b[i]);
        }
    }

    return 0;
}

/* Get heap statistics */
void mem_stats(word* total, word* free, word* used, word* blocks) {
    block_header_t* block;
    byte* ptr;

    *total = heap_size;
    *free = 0;
    *used = 0;
    *blocks = 0;

    if (!heap_initialized) {
        *free = heap_size;
        return;
    }

    ptr = heap_base;

    while (ptr < heap_base + heap_size) {
        block = (block_header_t*)ptr;

        if (block->guard != BLOCK_GUARD) break;

        (*blocks)++;

        if (block->flags == BLOCK_FREE) {
            *free += block->size - HEADER_SIZE;
        } else {
            *used += block->size - HEADER_SIZE;
        }

        ptr += block->size;
    }
}

/* Reallocate memory block */
void* mem_realloc(void* ptr, word new_size) {
    block_header_t* block;
    void* new_ptr;
    word old_size;
    word copy_size;

    if (ptr == 0) return mem_alloc(new_size);
    if (new_size == 0) {
        mem_free(ptr);
        return 0;
    }

    block = (block_header_t*)((byte*)ptr - HEADER_SIZE);
    old_size = block->size - HEADER_SIZE;

    /* Try to expand in place if next block is free */
    /* (Simplified - always allocate new block) */

    new_ptr = mem_alloc(new_size);
    if (new_ptr == 0) return 0;

    copy_size = (old_size < new_size) ? old_size : new_size;
    mem_copy((byte*)new_ptr, (const byte*)ptr, copy_size);
    mem_free(ptr);

    return new_ptr;
}

/* Compact heap (defragment free blocks) */
void mem_compact(void) {
    block_header_t* block;
    block_header_t* next;
    byte* ptr;
    byte moved;

    if (!heap_initialized) return;

    do {
        moved = 0;
        ptr = heap_base;

        while (ptr < heap_base + heap_size) {
            block = (block_header_t*)ptr;

            if (block->guard != BLOCK_GUARD) break;

            if (block->flags == BLOCK_FREE) {
                next = (block_header_t*)(ptr + block->size);

                if ((byte*)next < heap_base + heap_size &&
                    next->guard == BLOCK_GUARD && next->flags == BLOCK_FREE) {
                    /* Merge adjacent free blocks */
                    block->size += next->size;
                    moved = 1;
                    continue;  /* Re-check this block */
                }
            }

            ptr += block->size;
        }
    } while (moved);
}
