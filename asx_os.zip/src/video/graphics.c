/*
 * ASX Graphics Module - High-Resolution Graphics (Screen 2)
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * Screen 2: 256x192 pixels, 16 colors
 * 
 * VRAM Layout for Screen 2:
 *   Pattern Table:  0x0000-0x17FF (6144 bytes, 3 banks of 256 patterns)
 *   Color Table:    0x2000-0x37FF (6144 bytes, matches pattern layout)
 *   Name Table:     0x3800-0x3AFF (768 bytes, 32x24 character grid)
 *   
 * Each 8x8 pixel block is defined by:
 *   - Pattern byte (which pattern 0-255)
 *   - Color byte (foreground/background for each line)
 *   
 * The screen is divided into 3 zones (top, middle, bottom):
 *   - Each zone has its own pattern and color table (256 patterns each)
 *   - Name table selects which pattern to use in each 8x8 cell
 */

#include "../asx.h"

/* ========================================================================
 * SCREEN 2 CONSTANTS
 * ======================================================================== */

#define SCREEN2_WIDTH       256
#define SCREEN2_HEIGHT      192
#define CELL_SIZE           8
#define COLS_PER_ZONE       32
#define ROWS_PER_ZONE       8
#define PATTERNS_PER_ZONE   256

/* Zone base addresses in VRAM */
#define ZONE0_PATTERN       0x0000
#define ZONE1_PATTERN       0x0800
#define ZONE2_PATTERN       0x1000
#define ZONE0_COLOR         0x2000
#define ZONE1_COLOR         0x2800
#define ZONE2_COLOR         0x3000

/* ========================================================================
 * INTERNAL HELPERS
 * ======================================================================== */

/* Get zone (0-2) from Y coordinate */
static byte get_zone(byte y) {
    return y / (CELL_SIZE * ROWS_PER_ZONE);  /* 0, 1, or 2 */
}

/* Get pattern table base for a zone */
static word get_pattern_base(byte zone) {
    switch (zone) {
        case 0: return ZONE0_PATTERN;
        case 1: return ZONE1_PATTERN;
        case 2: return ZONE2_PATTERN;
        default: return ZONE0_PATTERN;
    }
}

/* Get color table base for a zone */
static word get_color_base(byte zone) {
    switch (zone) {
        case 0: return ZONE0_COLOR;
        case 1: return ZONE1_COLOR;
        case 2: return ZONE2_COLOR;
        default: return ZONE0_COLOR;
    }
}

/* Calculate cell coordinates */
static void get_cell(byte x, byte y, byte* cell_x, byte* cell_y, byte* pixel_x, byte* pixel_y) {
    *cell_x = x / CELL_SIZE;
    *cell_y = y / CELL_SIZE;
    *pixel_x = x % CELL_SIZE;
    *pixel_y = y % CELL_SIZE;
}

/* ========================================================================
 * INITIALIZATION
 * ======================================================================== */

void gfx_init(void) {
    word i;

    /* Ensure we're in Screen 2 mode */
    vdp_set_mode(SCREEN_2);

    /* Clear all pattern tables */
    for (i = 0; i < 0x1800; i++) {
        vdp_write_vram(ZONE0_PATTERN + i, 0x00);
    }

    /* Clear all color tables (set to transparent/background) */
    for (i = 0; i < 0x1800; i++) {
        vdp_write_vram(ZONE0_COLOR + i, 0x01);  /* Black background */
    }

    /* Initialize name table - each cell uses pattern = cell number */
    for (i = 0; i < 768; i++) {
        vdp_write_vram(VRAM_NAME + i, (byte)(i & 0xFF));
    }
}

/* ========================================================================
 * SCREEN CLEARING
 * ======================================================================== */

void gfx_clear(byte color) {
    word i;
    byte color_byte;

    color_byte = (color << 4) | (color & 0x0F);

    /* Clear pattern tables */
    for (i = 0; i < 0x1800; i++) {
        vdp_write_vram(ZONE0_PATTERN + i, 0x00);
    }

    /* Set color tables */
    for (i = 0; i < 0x1800; i++) {
        vdp_write_vram(ZONE0_COLOR + i, color_byte);
    }
}

/* ========================================================================
 * PIXEL OPERATIONS
 * ======================================================================== */

void gfx_put_pixel(byte x, byte y, byte color) {
    byte cell_x, cell_y, pixel_x, pixel_y;
    byte zone;
    word pattern_base, color_base;
    word pattern_addr, color_addr;
    byte pattern_byte, color_byte;
    byte mask;
    byte current_fg, current_bg;

    if (x >= SCREEN2_WIDTH || y >= SCREEN2_HEIGHT) return;

    get_cell(x, y, &cell_x, &cell_y, &pixel_x, &pixel_y);
    zone = get_zone(y);

    pattern_base = get_pattern_base(zone);
    color_base = get_color_base(zone);

    /* Pattern address: base + cell_number * 8 + pixel_y */
    pattern_addr = pattern_base + (word)cell_y * COLS_PER_ZONE * CELL_SIZE 
                   + (word)cell_x * CELL_SIZE + pixel_y;

    /* Color address: same offset in color table */
    color_addr = color_base + (pattern_addr - pattern_base);

    /* Read current pattern and color */
    pattern_byte = vdp_read_vram(pattern_addr);
    color_byte = vdp_read_vram(color_addr);

    current_fg = color_byte >> 4;
    current_bg = color_byte & 0x0F;

    /* Determine if we're setting foreground or background color */
    mask = 0x80 >> pixel_x;

    if (color == current_bg) {
        /* Set as background (clear bit) */
        pattern_byte &= ~mask;
    } else {
        /* Set as foreground (set bit) and update color */
        pattern_byte |= mask;
        if (color != current_fg) {
            color_byte = (color << 4) | current_bg;
        }
    }

    /* Write back */
    vdp_write_vram(pattern_addr, pattern_byte);
    vdp_write_vram(color_addr, color_byte);
}

byte gfx_get_pixel(byte x, byte y) {
    byte cell_x, cell_y, pixel_x, pixel_y;
    byte zone;
    word pattern_base, color_base;
    word pattern_addr, color_addr;
    byte pattern_byte, color_byte;
    byte mask;

    if (x >= SCREEN2_WIDTH || y >= SCREEN2_HEIGHT) return 0;

    get_cell(x, y, &cell_x, &cell_y, &pixel_x, &pixel_y);
    zone = get_zone(y);

    pattern_base = get_pattern_base(zone);
    color_base = get_color_base(zone);

    pattern_addr = pattern_base + (word)cell_y * COLS_PER_ZONE * CELL_SIZE 
                   + (word)cell_x * CELL_SIZE + pixel_y;
    color_addr = color_base + (pattern_addr - pattern_base);

    pattern_byte = vdp_read_vram(pattern_addr);
    color_byte = vdp_read_vram(color_addr);

    mask = 0x80 >> pixel_x;

    if (pattern_byte & mask) {
        return color_byte >> 4;  /* Foreground color */
    } else {
        return color_byte & 0x0F;  /* Background color */
    }
}

/* ========================================================================
 * LINE DRAWING (Bresenham's Algorithm)
 * ======================================================================== */

void gfx_line(byte x1, byte y1, byte x2, byte y2, byte color) {
    sword dx, dy;
    sword sx, sy;
    sword err, e2;

    dx = (x2 > x1) ? (sword)(x2 - x1) : (sword)(x1 - x2);
    dy = (y2 > y1) ? (sword)(y2 - y1) : (sword)(y1 - y2);

    sx = (x1 < x2) ? 1 : -1;
    sy = (y1 < y2) ? 1 : -1;

    err = dx - dy;

    for (;;) {
        gfx_put_pixel(x1, y1, color);

        if (x1 == x2 && y1 == y2) break;

        e2 = 2 * err;

        if (e2 > -dy) {
            err -= dy;
            x1 = (byte)((sword)x1 + sx);
        }

        if (e2 < dx) {
            err += dx;
            y1 = (byte)((sword)y1 + sy);
        }
    }
}

/* ========================================================================
 * RECTANGLE DRAWING
 * ======================================================================== */

void gfx_rect(byte x, byte y, byte w, byte h, byte color) {
    byte x2, y2;
    byte i;

    if (w == 0 || h == 0) return;

    x2 = x + w - 1;
    y2 = y + h - 1;

    /* Top and bottom edges */
    for (i = x; i <= x2; i++) {
        gfx_put_pixel(i, y, color);
        gfx_put_pixel(i, y2, color);
    }

    /* Left and right edges */
    for (i = y; i <= y2; i++) {
        gfx_put_pixel(x, i, color);
        gfx_put_pixel(x2, i, color);
    }
}

void gfx_fill_rect(byte x, byte y, byte w, byte h, byte color) {
    byte i, j;
    byte x2, y2;

    if (w == 0 || h == 0) return;

    x2 = x + w;
    y2 = y + h;

    for (j = y; j < y2; j++) {
        for (i = x; i < x2; i++) {
            gfx_put_pixel(i, j, color);
        }
    }
}

/* ========================================================================
 * CIRCLE DRAWING (Midpoint Algorithm)
 * ======================================================================== */

void gfx_circle(byte cx, byte cy, byte r, byte color) {
    sword x, y, d;

    x = 0;
    y = r;
    d = 3 - 2 * r;

    while (x <= y) {
        gfx_put_pixel((byte)(cx + x), (byte)(cy + y), color);
        gfx_put_pixel((byte)(cx - x), (byte)(cy + y), color);
        gfx_put_pixel((byte)(cx + x), (byte)(cy - y), color);
        gfx_put_pixel((byte)(cx - x), (byte)(cy - y), color);
        gfx_put_pixel((byte)(cx + y), (byte)(cy + x), color);
        gfx_put_pixel((byte)(cx - y), (byte)(cy + x), color);
        gfx_put_pixel((byte)(cx + y), (byte)(cy - x), color);
        gfx_put_pixel((byte)(cx - y), (byte)(cy - x), color);

        x++;
        if (d < 0) {
            d = d + 4 * x + 6;
        } else {
            d = d + 4 * (x - y) + 10;
            y--;
        }
    }
}

/* ========================================================================
 * PLOT (alias for put_pixel)
 * ======================================================================== */

void gfx_plot(byte x, byte y, byte color) {
    gfx_put_pixel(x, y, color);
}
