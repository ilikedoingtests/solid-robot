/*
 * ASX Joystick Input Module
 * Architecture for Synthesized eXchange
 * Version 1.0 - (C) 1986 ASX Systems, Inc.
 *
 * Supports 2 joystick ports
 * Each joystick: 4-directional + 2 buttons (A and B)
 * Compatible with standard 9-pin Atari-style joysticks
 */

#include "../asx.h"

/* ========================================================================
 * JOYSTICK BIT DEFINITIONS
 * ======================================================================== */

/* Port read bit layout (active low, 0 = pressed) */
#define JOY_UP          0x01
#define JOY_DOWN        0x02
#define JOY_LEFT        0x04
#define JOY_RIGHT       0x08
#define JOY_BUTTON_A    0x10
#define JOY_BUTTON_B    0x20
#define JOY_UNUSED_1    0x40
#define JOY_UNUSED_2    0x80

/* Button masks */
#define JOY_BUTTON_MASK (JOY_BUTTON_A | JOY_BUTTON_B)
#define JOY_DIR_MASK    (JOY_UP | JOY_DOWN | JOY_LEFT | JOY_RIGHT)

/* ========================================================================
 * INTERNAL STATE
 * ======================================================================== */

static byte joy1_state = 0xFF;  /* All released (active low) */
static byte joy2_state = 0xFF;
static byte joy1_prev = 0xFF;
static byte joy2_prev = 0xFF;

/* Callback for joystick events */
static void (*joy1_callback)(byte event, byte state) = 0;
static void (*joy2_callback)(byte event, byte state) = 0;

/* ========================================================================
 * INITIALIZATION
 * ======================================================================== */

void joy_init(void) {
    joy1_state = 0xFF;
    joy2_state = 0xFF;
    joy1_prev = 0xFF;
    joy2_prev = 0xFF;
    joy1_callback = 0;
    joy2_callback = 0;
}

/* ========================================================================
 * JOYSTICK READING
 * ======================================================================== */

/* Read joystick state from hardware port */
byte joy_read(byte port) {
    byte state;

    if (port == 1) {
        /* Read from PORT_JOYSTICK_1 */
        /* In real hardware: in a, (PORT_JOYSTICK_1) */
        /* For emulator, return cached state */
        state = joy1_state;
    } else if (port == 2) {
        /* Read from PORT_JOYSTICK_2 */
        state = joy2_state;
    } else {
        return 0xFF;
    }

    return state;
}

/* Check if specific button/direction is pressed */
bool joy_button(byte port, byte button) {
    byte state = joy_read(port);
    return (state & button) == 0;  /* Active low */
}

/* Get direction as a single value (0-8, 0 = center) */
byte joy_direction(byte port) {
    byte state = joy_read(port);
    byte dir = state & JOY_DIR_MASK;

    /* Return combined direction:
     * 0 = center, 1 = up, 2 = up-right, 3 = right, 4 = down-right,
     * 5 = down, 6 = down-left, 7 = left, 8 = up-left
     */
    switch (dir) {
        case 0xFE: return 1;  /* Up (11111110) */
        case 0xFA: return 2;  /* Up+Right */
        case 0xF7: return 3;  /* Right (11110111) */
        case 0xF5: return 4;  /* Down+Right */
        case 0xFD: return 5;  /* Down (11111101) */
        case 0xF9: return 6;  /* Down+Left */
        case 0xFB: return 7;  /* Left (11111011) */
        case 0xF8: return 8;  /* Up+Left */
        default: return 0;    /* Center or invalid */
    }
}

/* Get X axis (-1, 0, 1) */
sbyte joy_axis_x(byte port) {
    byte state = joy_read(port);

    if (!(state & JOY_LEFT)) return -1;
    if (!(state & JOY_RIGHT)) return 1;
    return 0;
}

/* Get Y axis (-1, 0, 1) */
sbyte joy_axis_y(byte port) {
    byte state = joy_read(port);

    if (!(state & JOY_UP)) return -1;
    if (!(state & JOY_DOWN)) return 1;
    return 0;
}

/* ========================================================================
 * JOYSTICK EVENTS
 * ======================================================================== */

/* Update joystick state (called from interrupt or main loop) */
void joy_update(void) {
    byte new_state;
    byte changes;

    /* Save previous state */
    joy1_prev = joy1_state;
    joy2_prev = joy2_state;

    /* Read current state from hardware */
    /* In real hardware, these would read from ports */
    /* joy1_state = bios_in(PORT_JOYSTICK_1); */
    /* joy2_state = bios_in(PORT_JOYSTICK_2); */

    /* Process port 1 changes */
    new_state = joy1_state;
    changes = joy1_prev ^ new_state;

    if (changes && joy1_callback) {
        /* Report changes */
        if (changes & JOY_UP) {
            joy1_callback(JOY_UP, !(new_state & JOY_UP));
        }
        if (changes & JOY_DOWN) {
            joy1_callback(JOY_DOWN, !(new_state & JOY_DOWN));
        }
        if (changes & JOY_LEFT) {
            joy1_callback(JOY_LEFT, !(new_state & JOY_LEFT));
        }
        if (changes & JOY_RIGHT) {
            joy1_callback(JOY_RIGHT, !(new_state & JOY_RIGHT));
        }
        if (changes & JOY_BUTTON_A) {
            joy1_callback(JOY_BUTTON_A, !(new_state & JOY_BUTTON_A));
        }
        if (changes & JOY_BUTTON_B) {
            joy1_callback(JOY_BUTTON_B, !(new_state & JOY_BUTTON_B));
        }
    }

    /* Process port 2 changes */
    new_state = joy2_state;
    changes = joy2_prev ^ new_state;

    if (changes && joy2_callback) {
        if (changes & JOY_UP) {
            joy2_callback(JOY_UP, !(new_state & JOY_UP));
        }
        if (changes & JOY_DOWN) {
            joy2_callback(JOY_DOWN, !(new_state & JOY_DOWN));
        }
        if (changes & JOY_LEFT) {
            joy2_callback(JOY_LEFT, !(new_state & JOY_LEFT));
        }
        if (changes & JOY_RIGHT) {
            joy2_callback(JOY_RIGHT, !(new_state & JOY_RIGHT));
        }
        if (changes & JOY_BUTTON_A) {
            joy2_callback(JOY_BUTTON_A, !(new_state & JOY_BUTTON_A));
        }
        if (changes & JOY_BUTTON_B) {
            joy2_callback(JOY_BUTTON_B, !(new_state & JOY_BUTTON_B));
        }
    }
}

/* Set callback for joystick events */
void joy_set_callback(byte port, void (*callback)(byte event, byte state)) {
    if (port == 1) {
        joy1_callback = callback;
    } else if (port == 2) {
        joy2_callback = callback;
    }
}

/* ========================================================================
 * JOYSTICK STATE QUERIES
 * ======================================================================== */

/* Check if any direction is pressed */
bool joy_any_direction(byte port) {
    return (joy_read(port) & JOY_DIR_MASK) != JOY_DIR_MASK;
}

/* Check if any button is pressed */
bool joy_any_button(byte port) {
    return (joy_read(port) & JOY_BUTTON_MASK) != JOY_BUTTON_MASK;
}

/* Check if joystick is in neutral position */
bool joy_centered(byte port) {
    return (joy_read(port) & JOY_DIR_MASK) == JOY_DIR_MASK;
}

/* Get raw state byte */
byte joy_get_raw(byte port) {
    return joy_read(port);
}

/* ========================================================================
 * EMULATOR INTERFACE
 * ======================================================================== */

/* Set joystick state (for emulator/frontend) */
void joy_set_state(byte port, byte state) {
    if (port == 1) {
        joy1_state = state;
    } else if (port == 2) {
        joy2_state = state;
    }
}

/* Simulate button press */
void joy_press(byte port, byte button) {
    if (port == 1) {
        joy1_state &= ~button;
    } else if (port == 2) {
        joy2_state &= ~button;
    }
}

/* Simulate button release */
void joy_release(byte port, byte button) {
    if (port == 1) {
        joy1_state |= button;
    } else if (port == 2) {
        joy2_state |= button;
    }
}

/* Simulate direction */
void joy_set_direction(byte port, byte dir) {
    byte state;

    /* Start with all directions released */
    state = 0xFF;

    /* Set pressed directions */
    switch (dir) {
        case 1: state &= ~JOY_UP; break;
        case 2: state &= ~(JOY_UP | JOY_RIGHT); break;
        case 3: state &= ~JOY_RIGHT; break;
        case 4: state &= ~(JOY_DOWN | JOY_RIGHT); break;
        case 5: state &= ~JOY_DOWN; break;
        case 6: state &= ~(JOY_DOWN | JOY_LEFT); break;
        case 7: state &= ~JOY_LEFT; break;
        case 8: state &= ~(JOY_UP | JOY_LEFT); break;
    }

    /* Preserve button state */
    if (port == 1) {
        state |= (joy1_state & JOY_BUTTON_MASK);
        joy1_state = state;
    } else if (port == 2) {
        state |= (joy2_state & JOY_BUTTON_MASK);
        joy2_state = state;
    }
}
